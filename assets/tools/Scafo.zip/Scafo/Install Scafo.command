#!/bin/bash
# Scafo — primary macOS installer — v0.1.0
# Double-click this file. If macOS blocks it: Right-click → Open → Open.
set +e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT" || exit 1

# Clear Gatekeeper quarantine on the whole package whenever possible
/usr/bin/xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null

clear 2>/dev/null
echo ""
echo "  Installing Scafo…"
echo ""

# Prefer Node installer when available
if command -v node >/dev/null 2>&1 && [[ -f "$ROOT/advanced/install.mjs" ]]; then
  /usr/bin/xattr -dr com.apple.quarantine "$ROOT/advanced" 2>/dev/null
  node "$ROOT/advanced/install.mjs" --root "$ROOT"
  status=$?
else
  /bin/chmod +x "$ROOT/advanced/install.sh" 2>/dev/null
  /usr/bin/xattr -dr com.apple.quarantine "$ROOT/advanced/install.sh" 2>/dev/null
  "$ROOT/advanced/install.sh"
  status=$?
fi

echo ""
if [[ $status -eq 0 ]]; then
  echo "  Done. You can close this window."
else
  echo "  Install reported a problem (exit $status)."
  echo "  If macOS blocked the script earlier: Right-click this file → Open."
fi
echo ""
read -r -n 1 -s -p "  Press any key to close…"
echo ""
exit "$status"
