#!/bin/bash
cd "$(dirname "$0")/.." || exit 1
chmod +x ./advanced/uninstall.sh 2>/dev/null || true
./advanced/uninstall.sh
echo ""
read -r -n 1 -s -p "Press any key to close…"
echo ""
