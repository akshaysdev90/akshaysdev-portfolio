Scafo — universal package v0.1.0
=====================================

Download Scafo once. Install once. Use in Figma, Illustrator, Photoshop, and InDesign.

Primary install
---------------
  Mac:     Install Scafo.command   (or Install Scafo.app)
  Windows: Install Scafo.bat

What install does
-----------------
  • Enables Adobe CEP for unsigned local panels
  • Installs Scafo for Illustrator, Photoshop, and InDesign
  • Places the Figma plugin in a stable folder
  • Opens the Figma import helper + copies the manifest path
  • Safe to re-run (updates in place)

Open after install
------------------
  Illustrator  Window → Extensions → Scafo
  Photoshop    Window → Extensions (legacy) → Scafo
  InDesign     Window → Extensions → Scafo
  Figma        Plugins → Development → Scafo  (after one Import step)

Quit & relaunch Adobe apps the first time.

Host notes
----------
  Same Analyse everywhere.
  Figma: canvas text + PNG export
  Adobe: applies type hierarchy into the active document

advanced/  — uninstall + developer scripts
