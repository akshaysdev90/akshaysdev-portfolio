(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // ../../packages/hosts/src/protocol.ts
  function buildFontCandidates(family, style) {
    const fam = family.trim();
    const sty = (style || "Regular").trim();
    const noSpace = fam.replace(/\s+/g, "");
    const psStyle = sty.replace(/\s+/g, "");
    const out = [];
    const push2 = (v) => {
      if (v && !out.includes(v)) out.push(v);
    };
    push2(`${fam}-${psStyle}`);
    push2(`${noSpace}-${psStyle}`);
    push2(`${fam}${psStyle}`);
    push2(`${noSpace}${psStyle}`);
    if (/regular|roman|book/i.test(sty)) {
      push2(`${fam}-Regular`);
      push2(`${noSpace}-Regular`);
      push2(`${fam}MT`);
      push2(`${noSpace}MT`);
      push2(fam);
      push2(noSpace);
    }
    if (/bold/i.test(sty) && !/semibold|demi/i.test(sty)) {
      push2(`${fam}-Bold`);
      push2(`${noSpace}-Bold`);
      push2(`${fam}-BoldMT`);
      push2(`${noSpace}-BoldMT`);
      push2(`${fam}Bold`);
      push2(`${noSpace}Bold`);
    }
    if (/italic|oblique/i.test(sty)) {
      push2(`${fam}-Italic`);
      push2(`${noSpace}-Italic`);
      push2(`${fam}-Oblique`);
    }
    if (/semibold|semi bold|demi/i.test(sty)) {
      push2(`${fam}-SemiBold`);
      push2(`${noSpace}-SemiBold`);
      push2(`${fam}-Demibold`);
      push2(`${noSpace}-Demibold`);
    }
    if (/medium/i.test(sty)) {
      push2(`${fam}-Medium`);
      push2(`${noSpace}-Medium`);
    }
    if (/light/i.test(sty)) {
      push2(`${fam}-Light`);
      push2(`${noSpace}-Light`);
    }
    for (const alias of aliasFamilies(fam)) {
      push2(alias);
      push2(`${alias}-${psStyle}`);
      push2(alias.replace(/\s+/g, ""));
    }
    push2("ArialMT");
    push2("Arial-BoldMT");
    push2("Helvetica");
    push2("Helvetica-Bold");
    push2("MyriadPro-Regular");
    push2("MinionPro-Regular");
    return out;
  }
  function aliasFamilies(family) {
    var _a;
    const map = {
      helvetica: ["Helvetica Neue", "Arial", "ArialMT"],
      "helvetica neue": ["Helvetica", "Arial"],
      "times new roman": ["Times", "Times New Roman", "Georgia"],
      garamond: ["Adobe Garamond Pro", "EB Garamond", "Garamond"],
      "source sans 3": ["Source Sans Pro", "Source Sans 3"],
      "source serif 4": ["Source Serif Pro", "Source Serif 4"],
      "sf pro": ["SF Pro Text", "Helvetica Neue", "Arial"],
      inter: ["Inter", "Arial", "Helvetica"],
      roboto: ["Roboto", "Arial"],
      poppins: ["Poppins", "Arial"]
    };
    return (_a = map[family.toLowerCase()]) != null ? _a : [];
  }

  // ../../packages/hosts/src/adobe/cep.ts
  function isCepEnvironment() {
    return typeof window !== "undefined" && Boolean(window.__adobe_cep__);
  }
  function createCSInterface() {
    if (typeof window.CSInterface === "function") {
      return new window.CSInterface();
    }
    const bridge = window.__adobe_cep__;
    if (!bridge) {
      throw new Error("Not running inside Adobe CEP.");
    }
    return {
      evalScript(script, callback) {
        bridge.evalScript(script, callback != null ? callback : (() => void 0));
      },
      getSystemPath(pathType) {
        return decodeURI(bridge.getSystemPath(String(pathType)));
      },
      getHostEnvironment() {
        return bridge.getHostEnvironment();
      }
    };
  }
  function evalScriptAsync(cs, script) {
    return new Promise((resolve, reject) => {
      try {
        cs.evalScript(script, (result) => {
          try {
            if (result === "EvalScript_Err!") {
              reject(new Error("ExtendScript evaluation failed."));
              return;
            }
            resolve(result != null ? result : "");
          } catch (err) {
            reject(err instanceof Error ? err : new Error(String(err)));
          }
        });
      } catch (err) {
        reject(err instanceof Error ? err : new Error(String(err)));
      }
    });
  }
  async function evalScriptSafe(cs, script) {
    try {
      const result = await evalScriptAsync(cs, script);
      return { ok: true, result };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err : new Error(String(err))
      };
    }
  }
  function toExtendScriptPath(fsPath) {
    return fsPath.replace(/\\/g, "/");
  }

  // ../../packages/core/src/catalog.ts
  var FONT_CATALOG = [
    {
      family: "Inter",
      category: "humanist-sans",
      mood: ["neutral", "tech", "friendly"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Source Serif 4", "Merriweather", "Libre Baskerville", "IBM Plex Serif"],
      avoid: ["Roboto", "Helvetica"],
      styles: ["Regular", "Medium", "Semi Bold", "Bold"],
      aliases: ["Inter Display"]
    },
    {
      family: "Roboto",
      category: "sans",
      mood: ["neutral", "tech"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Roboto Slab", "Merriweather", "Playfair Display", "Source Serif 4"],
      avoid: ["Inter", "Arial"],
      styles: ["Regular", "Medium", "Bold"]
    },
    {
      family: "Helvetica",
      category: "sans",
      mood: ["neutral", "classic", "bold"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Times New Roman", "Georgia", "Garamond", "Playfair Display"],
      avoid: ["Arial", "Roboto"],
      styles: ["Regular", "Bold", "Light"],
      aliases: ["Helvetica Neue", "Helvetica Neue Regular"]
    },
    {
      family: "Arial",
      category: "sans",
      mood: ["neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Georgia", "Times New Roman", "Merriweather", "Garamond"],
      avoid: ["Helvetica", "Roboto"],
      styles: ["Regular", "Bold"]
    },
    {
      family: "Poppins",
      category: "geometric-sans",
      mood: ["friendly", "bold", "playful"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Playfair Display", "Lora", "Source Serif 4", "Merriweather"],
      avoid: ["Montserrat", "Nunito"],
      styles: ["Regular", "Medium", "SemiBold", "Bold"]
    },
    {
      family: "Montserrat",
      category: "geometric-sans",
      mood: ["bold", "neutral", "tech"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Merriweather", "Playfair Display", "Cormorant Garamond", "Lora"],
      avoid: ["Poppins", "Raleway"],
      styles: ["Regular", "Medium", "SemiBold", "Bold"]
    },
    {
      family: "Work Sans",
      category: "humanist-sans",
      mood: ["friendly", "neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Libre Baskerville", "Source Serif 4", "Lora"],
      avoid: [],
      styles: ["Regular", "Medium", "SemiBold", "Bold"]
    },
    {
      family: "DM Sans",
      category: "geometric-sans",
      mood: ["tech", "neutral", "friendly"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["DM Serif Display", "Source Serif 4", "Libre Baskerville"],
      avoid: [],
      styles: ["Regular", "Medium", "Bold"]
    },
    {
      family: "Space Grotesk",
      category: "geometric-sans",
      mood: ["tech", "bold"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["Space Mono", "IBM Plex Serif", "Source Serif 4"],
      avoid: [],
      styles: ["Regular", "Medium", "Bold"]
    },
    {
      family: "Oswald",
      category: "display",
      mood: ["bold", "editorial"],
      contrast: "medium",
      xHeight: "low",
      pairWith: ["Source Sans 3", "Open Sans", "Lato", "Roboto"],
      avoid: ["Bebas Neue", "Impact"],
      styles: ["Regular", "Medium", "Bold"]
    },
    {
      family: "Bebas Neue",
      category: "display",
      mood: ["bold", "playful"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Roboto", "Open Sans", "Lato", "Source Sans 3"],
      avoid: ["Oswald", "Impact"],
      styles: ["Regular"]
    },
    {
      family: "Playfair Display",
      category: "transitional-serif",
      mood: ["luxury", "editorial", "classic"],
      contrast: "high",
      xHeight: "low",
      pairWith: ["Source Sans 3", "Lato", "Montserrat", "Work Sans"],
      avoid: ["Cormorant Garamond", "Libre Baskerville"],
      styles: ["Regular", "Medium", "Bold", "Italic"]
    },
    {
      family: "Merriweather",
      category: "transitional-serif",
      mood: ["editorial", "classic", "friendly"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["Open Sans", "Source Sans 3", "Montserrat", "Lato"],
      avoid: ["Georgia"],
      styles: ["Regular", "Bold", "Italic"]
    },
    {
      family: "Lora",
      category: "old-style-serif",
      mood: ["editorial", "friendly", "classic"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["Lato", "Source Sans 3", "Montserrat", "Poppins"],
      avoid: [],
      styles: ["Regular", "Medium", "Bold", "Italic"]
    },
    {
      family: "Libre Baskerville",
      category: "old-style-serif",
      mood: ["classic", "editorial", "luxury"],
      contrast: "medium",
      xHeight: "low",
      pairWith: ["Source Sans 3", "Montserrat", "Work Sans", "Inter"],
      avoid: ["Garamond"],
      styles: ["Regular", "Bold", "Italic"]
    },
    {
      family: "Source Serif 4",
      category: "transitional-serif",
      mood: ["editorial", "neutral", "classic"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["Source Sans 3", "Inter", "Work Sans", "DM Sans"],
      avoid: [],
      styles: ["Regular", "SemiBold", "Bold"],
      aliases: ["Source Serif Pro", "Source Serif"]
    },
    {
      family: "Source Sans 3",
      category: "humanist-sans",
      mood: ["neutral", "friendly", "editorial"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Source Serif 4", "Playfair Display", "Merriweather", "Lora"],
      avoid: [],
      styles: ["Regular", "Medium", "SemiBold", "Bold"],
      aliases: ["Source Sans Pro", "Source Sans"]
    },
    {
      family: "Open Sans",
      category: "humanist-sans",
      mood: ["friendly", "neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Merriweather", "Playfair Display", "Lora", "Georgia"],
      avoid: ["Lato"],
      styles: ["Regular", "SemiBold", "Bold"]
    },
    {
      family: "Lato",
      category: "humanist-sans",
      mood: ["friendly", "neutral", "classic"],
      contrast: "low",
      xHeight: "medium",
      pairWith: ["Merriweather", "Playfair Display", "Lora", "Libre Baskerville"],
      avoid: ["Open Sans"],
      styles: ["Regular", "Bold", "Light"]
    },
    {
      family: "Georgia",
      category: "transitional-serif",
      mood: ["classic", "editorial", "neutral"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["Verdana", "Arial", "Helvetica", "Source Sans 3"],
      avoid: ["Times New Roman", "Merriweather"],
      styles: ["Regular", "Bold", "Italic"]
    },
    {
      family: "Times New Roman",
      category: "transitional-serif",
      mood: ["classic", "editorial"],
      contrast: "high",
      xHeight: "low",
      pairWith: ["Helvetica", "Arial", "Gill Sans", "Futura"],
      avoid: ["Georgia", "Garamond"],
      styles: ["Regular", "Bold", "Italic"],
      aliases: ["Times"]
    },
    {
      family: "Garamond",
      category: "old-style-serif",
      mood: ["classic", "luxury", "editorial"],
      contrast: "medium",
      xHeight: "low",
      pairWith: ["Helvetica", "Gill Sans", "Futura", "Montserrat"],
      avoid: ["Times New Roman", "Libre Baskerville"],
      styles: ["Regular", "Bold", "Italic"],
      aliases: ["EB Garamond", "Adobe Garamond Pro"]
    },
    {
      family: "Cormorant Garamond",
      category: "modern-serif",
      mood: ["luxury", "editorial"],
      contrast: "high",
      xHeight: "low",
      pairWith: ["Montserrat", "Work Sans", "Lato", "Josefin Sans"],
      avoid: ["Playfair Display"],
      styles: ["Regular", "Medium", "Bold", "Italic"]
    },
    {
      family: "IBM Plex Serif",
      category: "transitional-serif",
      mood: ["tech", "editorial", "neutral"],
      contrast: "medium",
      xHeight: "medium",
      pairWith: ["IBM Plex Sans", "Inter", "Space Grotesk"],
      avoid: [],
      styles: ["Regular", "Medium", "SemiBold", "Bold"]
    },
    {
      family: "IBM Plex Sans",
      category: "humanist-sans",
      mood: ["tech", "neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["IBM Plex Serif", "Source Serif 4", "Merriweather"],
      avoid: [],
      styles: ["Regular", "Medium", "SemiBold", "Bold"]
    },
    {
      family: "Roboto Slab",
      category: "slab",
      mood: ["tech", "friendly", "bold"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Roboto", "Open Sans", "Source Sans 3"],
      avoid: [],
      styles: ["Regular", "Medium", "Bold"]
    },
    {
      family: "DM Serif Display",
      category: "display",
      mood: ["editorial", "luxury"],
      contrast: "high",
      xHeight: "low",
      pairWith: ["DM Sans", "Inter", "Work Sans"],
      avoid: [],
      styles: ["Regular", "Italic"]
    },
    {
      family: "Futura",
      category: "geometric-sans",
      mood: ["classic", "bold", "luxury"],
      contrast: "low",
      xHeight: "low",
      pairWith: ["Garamond", "Bodoni", "Playfair Display", "Times New Roman"],
      avoid: ["Montserrat", "Poppins"],
      styles: ["Medium", "Bold", "Book"]
    },
    {
      family: "Gill Sans",
      category: "humanist-sans",
      mood: ["classic", "neutral"],
      contrast: "low",
      xHeight: "medium",
      pairWith: ["Garamond", "Baskerville", "Times New Roman"],
      avoid: [],
      styles: ["Regular", "Bold", "Light"],
      aliases: ["Gill Sans MT"]
    },
    {
      family: "Verdana",
      category: "sans",
      mood: ["friendly", "neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["Georgia", "Palatino", "Merriweather"],
      avoid: ["Tahoma"],
      styles: ["Regular", "Bold"]
    },
    {
      family: "SF Pro",
      category: "humanist-sans",
      mood: ["tech", "neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: ["New York", "Charter", "Source Serif 4", "Georgia"],
      avoid: ["Inter", "Roboto"],
      styles: ["Regular", "Medium", "Semibold", "Bold"],
      aliases: ["SF Pro Text", "San Francisco"]
    },
    {
      family: "SeoulNamsan",
      category: "sans",
      mood: ["bold", "neutral"],
      contrast: "low",
      xHeight: "medium",
      pairWith: ["Amiri", "Noto Serif", "Source Serif 4", "Georgia"],
      avoid: [],
      styles: ["EB", "Regular", "Bold"],
      aliases: ["Seoul Namsan", "SeoulNamsan EB"]
    }
  ];

  // ../../packages/core/src/match.ts
  function normalize(name) {
    return name.trim().toLowerCase().replace(/[\u2019']/g, "").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function tokenSet(name) {
    return new Set(normalize(name).split(" ").filter(Boolean));
  }
  function jaccard(a, b) {
    let inter = 0;
    for (const t of a) if (b.has(t)) inter += 1;
    const union = a.size + b.size - inter;
    return union === 0 ? 0 : inter / union;
  }
  function inferCategory(fontName) {
    const n = normalize(fontName);
    if (/\b(mono|code|consolas|courier|menlo|fira code)\b/.test(n)) return "mono";
    if (/\b(script|hand|cursive|calligraphy|brush)\b/.test(n)) return "script";
    if (/\b(slab|rockwell|clarendon|museo)\b/.test(n)) return "slab";
    if (/\b(display|black|impact|bebas|poster)\b/.test(n)) return "display";
    if (/\b(serif|baskerville|garamond|bodoni|didot|times|georgia|playfair|lora|merriweather)\b/.test(n)) {
      return "serif";
    }
    if (/\b(futura|gilroy|circular|montserrat|poppins|avant)\b/.test(n)) return "geometric-sans";
    return "sans";
  }
  function findFontProfile(fontName) {
    var _a, _b;
    const needle = normalize(fontName);
    if (!needle) return null;
    for (const font of FONT_CATALOG) {
      const names = [font.family, ...(_a = font.aliases) != null ? _a : []];
      if (names.some((n) => normalize(n) === needle)) return font;
    }
    let best = null;
    let bestScore = 0;
    const needleTokens = tokenSet(fontName);
    for (const font of FONT_CATALOG) {
      const names = [font.family, ...(_b = font.aliases) != null ? _b : []];
      for (const candidate of names) {
        const cand = normalize(candidate);
        if (needle.includes(cand) || cand.includes(needle)) {
          const score = Math.min(needle.length, cand.length) / Math.max(needle.length, cand.length) + 0.15;
          if (score > bestScore) {
            bestScore = score;
            best = font;
          }
        }
        const overlap = jaccard(needleTokens, tokenSet(candidate));
        if (overlap > bestScore) {
          bestScore = overlap;
          best = font;
        }
      }
    }
    return bestScore >= 0.45 ? best : null;
  }
  function toProfile(fontName) {
    const matched = findFontProfile(fontName);
    if (matched) return matched;
    const category = inferCategory(fontName);
    const isSerif3 = category.includes("serif") || category === "slab";
    return {
      family: fontName.trim() || "Inter",
      category,
      mood: ["neutral"],
      contrast: isSerif3 ? "medium" : "low",
      xHeight: "medium",
      pairWith: isSerif3 ? ["Inter", "Source Sans 3", "Helvetica", "Montserrat"] : ["Source Serif 4", "Merriweather", "Playfair Display", "Georgia"],
      avoid: [],
      styles: ["Regular", "Medium", "Bold"]
    };
  }

  // ../../packages/core/src/pairing.ts
  var SERIFISH = /* @__PURE__ */ new Set([
    "serif",
    "slab",
    "old-style-serif",
    "transitional-serif",
    "modern-serif"
  ]);
  var SANSISH = /* @__PURE__ */ new Set([
    "sans",
    "humanist-sans",
    "geometric-sans"
  ]);
  function isSerif(cat) {
    return SERIFISH.has(cat);
  }
  function isSans(cat) {
    return SANSISH.has(cat);
  }
  function moodOverlap(a, b) {
    let n = 0;
    for (const m of a) if (b.includes(m)) n += 1;
    return n;
  }
  function categoryContrastBonus(main, candidate) {
    if (main === candidate) return -1.2;
    if (isSerif(main) && isSans(candidate)) return 2.4;
    if (isSans(main) && isSerif(candidate)) return 2.4;
    if (main === "display" && (isSans(candidate) || isSerif(candidate))) return 2;
    if (main === "slab" && isSans(candidate)) return 1.8;
    if (main === "geometric-sans" && candidate === "humanist-sans") return 0.8;
    if (main === "humanist-sans" && candidate === "geometric-sans") return 0.6;
    if (main === "mono") return isSans(candidate) || isSerif(candidate) ? 1.2 : -0.5;
    if (main === "script" && isSans(candidate)) return 1.6;
    return 0.2;
  }
  function scoreCompanion(main, candidate, role2) {
    if (normalize2(candidate.family) === normalize2(main.family)) return -100;
    let score = 0;
    score += categoryContrastBonus(main.category, candidate.category);
    if (main.pairWith.some((p) => normalize2(p) === normalize2(candidate.family))) {
      score += 3.5;
    }
    if (main.avoid.some((a) => normalize2(a) === normalize2(candidate.family))) {
      score -= 4;
    }
    const moods = moodOverlap(main.mood, candidate.mood);
    score += moods * 0.55;
    if (role2 === "subheader") {
      if (main.xHeight !== candidate.xHeight) score += 0.5;
      if (main.contrast !== candidate.contrast) score += 0.35;
    }
    if (role2 === "body") {
      if (candidate.xHeight === "high") score += 0.7;
      if (candidate.category === "display" || candidate.category === "script") score -= 2.5;
      if (candidate.contrast === "high" && isSerif(candidate.category)) score -= 0.3;
    }
    if (main.category === "geometric-sans" && candidate.category === "geometric-sans") {
      score -= 1.5;
    }
    return score;
  }
  function normalize2(s) {
    return s.trim().toLowerCase();
  }
  function pairFonts(mainFontName) {
    var _a, _b;
    const main = toProfile(mainFontName);
    const pool = FONT_CATALOG.filter(
      (f) => normalize2(f.family) !== normalize2(main.family)
    );
    const preferred = main.pairWith.map((name) => FONT_CATALOG.find((f) => normalize2(f.family) === normalize2(name))).filter((f) => Boolean(f));
    const candidates = preferred.length ? [...preferred, ...pool] : pool;
    let bestSub = (_a = candidates[0]) != null ? _a : fallbackSans();
    let bestSubScore = -Infinity;
    for (const c of candidates) {
      const s = scoreCompanion(main, c, "subheader");
      if (s > bestSubScore) {
        bestSubScore = s;
        bestSub = c;
      }
    }
    let bestBody = (_b = candidates.find((c) => c.family !== bestSub.family)) != null ? _b : fallbackSans();
    let bestBodyScore = -Infinity;
    for (const c of candidates) {
      if (normalize2(c.family) === normalize2(bestSub.family)) continue;
      let s = scoreCompanion(main, c, "body");
      if (shareFoundryHint(bestSub.family, c.family)) s += 0.9;
      if (isSerif(bestSub.category) && isSans(c.category)) s += 0.45;
      if (isSans(bestSub.category) && isSerif(c.category)) s += 0.25;
      if (s > bestBodyScore) {
        bestBodyScore = s;
        bestBody = c;
      }
    }
    if (main.category === "display" && isSans(bestSub.category)) {
      const relatedBody = candidates.find(
        (c) => isSans(c.category) && c.xHeight === "high" && normalize2(c.family) !== normalize2(bestSub.family)
      );
      if (relatedBody && scoreCompanion(main, relatedBody, "body") >= bestBodyScore - 0.5) {
        bestBody = relatedBody;
      }
    }
    const rationale = buildRationale(main, bestSub, bestBody);
    return { subheader: bestSub, body: bestBody, rationale };
  }
  function shareFoundryHint(a, b) {
    const prefixes = ["Source ", "IBM Plex ", "DM ", "Roboto ", "Noto "];
    return prefixes.some((p) => a.startsWith(p) && b.startsWith(p));
  }
  function fallbackSans() {
    var _a;
    return (_a = FONT_CATALOG.find((f) => f.family === "Inter")) != null ? _a : {
      family: "Inter",
      category: "humanist-sans",
      mood: ["neutral"],
      contrast: "low",
      xHeight: "high",
      pairWith: [],
      avoid: [],
      styles: ["Regular", "Medium", "Bold"]
    };
  }
  function buildRationale(main, sub, body) {
    const contrast = isSerif(main.category) && isSans(sub.category) || isSans(main.category) && isSerif(sub.category) ? "contrasting categories" : "complementary texture";
    return `${main.family} paired with ${sub.family} (${contrast}); ${body.family} for readable body.`;
  }
  function pickStyle(profile, role2) {
    var _a, _b, _c, _d, _e, _f, _g;
    const styles = profile.styles;
    if (role2 === "headline") {
      return (_b = (_a = styles.find((s) => /bold|black|eb|heavy/i.test(s))) != null ? _a : styles[styles.length - 1]) != null ? _b : "Regular";
    }
    if (role2 === "subheader") {
      return (_e = (_d = (_c = styles.find((s) => /semi|medium|demi/i.test(s))) != null ? _c : styles.find((s) => /bold/i.test(s))) != null ? _d : styles[0]) != null ? _e : "Regular";
    }
    return (_g = (_f = styles.find((s) => /regular|book|roman/i.test(s))) != null ? _f : styles[0]) != null ? _g : "Regular";
  }

  // ../../packages/core/src/scale.ts
  var SCALES = [
    { ratio: 1.2, name: "Minor Third" },
    { ratio: 1.25, name: "Major Third" },
    { ratio: 1.333, name: "Perfect Fourth" },
    { ratio: 1.414, name: "Augmented Fourth" },
    { ratio: 1.5, name: "Perfect Fifth" },
    { ratio: 1.618, name: "Golden Ratio" }
  ];
  function chooseScale(mainSize, canvasWidth, canvasHeight) {
    const area = Math.max(1, canvasWidth * canvasHeight);
    const shortSide = Math.min(canvasWidth, canvasHeight);
    const drama = mainSize / Math.max(12, shortSide);
    const areaScore = Math.log10(area) / 7;
    let score = drama * 2.2 + areaScore;
    if (mainSize >= 96) score += 0.35;
    if (mainSize >= 128) score += 0.25;
    if (shortSide < 600) score -= 0.35;
    if (score < 0.55) return SCALES[0];
    if (score < 0.85) return SCALES[1];
    if (score < 1.15) return SCALES[2];
    if (score < 1.45) return SCALES[3];
    if (score < 1.75) return SCALES[4];
    return SCALES[5];
  }
  function roundTypeSize(value) {
    if (value < 10) return Math.max(8, Math.round(value));
    if (value < 20) return Math.round(value * 2) / 2;
    if (value < 48) return Math.round(value);
    return Math.round(value / 2) * 2;
  }
  function computeHierarchy(mainSize, canvasWidth, canvasHeight) {
    const size = Math.max(8, mainSize);
    const scale = chooseScale(size, canvasWidth, canvasHeight);
    let subheader = size / scale.ratio;
    let body = size / (scale.ratio * scale.ratio);
    const idealBody = clamp(canvasWidth / 58, 12, 22);
    const minBody = clamp(shortSideFactor(canvasHeight) * 11, 11, 16);
    const maxBody = Math.min(idealBody + 4, size / 1.8);
    body = clamp(body, minBody, maxBody);
    if (subheader < body * 1.15) {
      subheader = body * 1.25;
    }
    if (subheader > size * 0.85) {
      subheader = size / Math.max(1.2, scale.ratio);
    }
    body = body * 0.65 + idealBody * 0.35;
    body = clamp(body, minBody, Math.min(maxBody, subheader / 1.2));
    return {
      headline: roundTypeSize(size),
      subheader: roundTypeSize(subheader),
      body: roundTypeSize(body),
      ratio: scale.ratio,
      scaleName: scale.name
    };
  }
  function clamp(n, min, max) {
    return Math.min(max, Math.max(min, n));
  }
  function shortSideFactor(height) {
    if (height < 500) return 0.95;
    if (height > 1400) return 1.15;
    return 1;
  }

  // ../../packages/core/src/pairingScore.ts
  var SERIFISH2 = /* @__PURE__ */ new Set([
    "serif",
    "slab",
    "old-style-serif",
    "transitional-serif",
    "modern-serif"
  ]);
  var SANSISH2 = /* @__PURE__ */ new Set([
    "sans",
    "humanist-sans",
    "geometric-sans"
  ]);
  function isSerif2(cat) {
    return SERIFISH2.has(cat) || /serif/i.test(cat) && !/sans/i.test(cat);
  }
  function isSans2(cat) {
    return SANSISH2.has(cat) || /sans/i.test(cat);
  }
  function moodOverlap2(a, b) {
    let n = 0;
    for (const m of a) if (b.includes(m)) n += 1;
    return n;
  }
  function normalize3(s) {
    return s.trim().toLowerCase();
  }
  function categoryContrastBonus2(main, candidate) {
    if (main === candidate) return -1.2;
    if (isSerif2(main) && isSans2(candidate)) return 2.6;
    if (isSans2(main) && isSerif2(candidate)) return 2.6;
    if (main === "display" && (isSans2(candidate) || isSerif2(candidate))) return 2.1;
    if (main === "slab" && isSans2(candidate)) return 1.9;
    if (main === "mono") return isSans2(candidate) || isSerif2(candidate) ? 1.2 : -0.5;
    if (main === "script" && isSans2(candidate)) return 1.7;
    return 0.2;
  }
  function scorePairAgainstMain(main, candidate, role2) {
    if (normalize3(candidate.family) === normalize3(main.family)) return -100;
    let score = 0;
    score += categoryContrastBonus2(main.category, candidate.category);
    if (main.pairWith.some((p) => normalize3(p) === normalize3(candidate.family))) {
      score += role2 === "subheader" ? 3.5 : 1.1;
    }
    if (main.avoid.some((a) => normalize3(a) === normalize3(candidate.family))) {
      score -= 4;
    }
    score += moodOverlap2(main.mood, candidate.mood) * 0.55;
    if (role2 === "subheader") {
      if (main.xHeight !== candidate.xHeight) score += 0.5;
      if (main.contrast !== candidate.contrast) score += 0.35;
    }
    if (role2 === "body") {
      if (candidate.xHeight === "high") score += 0.85;
      if (candidate.category === "display" || candidate.category === "script") score -= 2.8;
      if (candidate.category === "slab" || candidate.category === "mono") score -= 1.6;
      if (candidate.contrast === "high" && isSerif2(candidate.category)) score -= 0.25;
      if (/source sans|ibm plex sans|inter|noto sans|roboto$|manrope|figtree|literata|source serif|merriweather|lora|libre baskerville|newsreader|open sans|lato|nunito sans/.test(
        candidate.family.toLowerCase()
      )) {
        score += 1.2;
      }
    }
    if (main.category === "geometric-sans" && candidate.category === "geometric-sans") {
      score -= 1.5;
    }
    return score;
  }

  // ../../packages/core/src/topOptions.ts
  function normalize4(s) {
    return s.trim().toLowerCase();
  }
  function categoryFamily(cat) {
    if (/sans/i.test(cat)) return "sans";
    if (/serif/i.test(cat) || cat === "slab") return "serif";
    return "other";
  }
  function diversityPenalty(candidate, chosen) {
    let penalty = 0;
    const fam = categoryFamily(candidate.category);
    for (const prev of chosen) {
      if (normalize4(prev.family) === normalize4(candidate.family)) return 100;
      if (categoryFamily(prev.category) === fam) penalty += 1.8;
      const sharedMood = candidate.mood.filter((m) => prev.mood.includes(m)).length;
      if (sharedMood >= 2) penalty += 0.6;
      const a = normalize4(prev.family).slice(0, 6);
      const b = normalize4(candidate.family).slice(0, 6);
      if (a.length >= 5 && a === b) penalty += 1.2;
    }
    return penalty;
  }
  function pickTopOptions(main, pool, role2, count, reserved = []) {
    const reservedNorm = new Set(
      [main, ...reserved].map((p) => normalize4(p.family))
    );
    const ranked = pool.filter((p) => !reservedNorm.has(normalize4(p.family))).map((p) => ({ p, s: scorePairAgainstMain(main, p, role2) })).sort((a, b) => b.s - a.s);
    const picks = [];
    const used = /* @__PURE__ */ new Set();
    for (const { p, s } of ranked) {
      if (picks.length >= count) break;
      const key = normalize4(p.family);
      if (used.has(key)) continue;
      if (s < -2) continue;
      const penalty = diversityPenalty(p, picks);
      if (picks.length > 0 && penalty >= 3.2 && s < ranked[0].s - 0.5) {
        continue;
      }
      if (picks.length > 0 && penalty > 2.4) continue;
      picks.push(p);
      used.add(key);
    }
    if (picks.length < count) {
      for (const { p } of ranked) {
        if (picks.length >= count) break;
        const key = normalize4(p.family);
        if (used.has(key) || reservedNorm.has(key)) continue;
        picks.push(p);
        used.add(key);
      }
    }
    return picks;
  }
  function scoreBodyWithSub(main, sub, candidate) {
    if (normalize4(candidate.family) === normalize4(sub.family)) return -100;
    let s = scorePairAgainstMain(main, candidate, "body");
    if (/serif/i.test(sub.category) && /sans/i.test(candidate.category)) s += 1.8;
    if (/sans/i.test(sub.category) && /serif/i.test(candidate.category)) s += 1.1;
    if (/serif/i.test(sub.category) && /serif/i.test(candidate.category) && !/sans/i.test(candidate.category)) {
      s -= 2.2;
    }
    if (/sans/i.test(sub.category) && /sans/i.test(candidate.category)) s -= 0.8;
    return s;
  }
  function pickTopBodyOptions(main, pool, primarySub, count, reservedSubs) {
    const reserved = [primarySub, ...reservedSubs];
    const reservedNorm = new Set(
      [main, ...reserved].map((p) => normalize4(p.family))
    );
    const ranked = pool.filter((p) => !reservedNorm.has(normalize4(p.family))).map((p) => ({ p, s: scoreBodyWithSub(main, primarySub, p) })).sort((a, b) => b.s - a.s);
    const picks = [];
    const used = /* @__PURE__ */ new Set();
    for (const { p, s } of ranked) {
      if (picks.length >= count) break;
      const key = normalize4(p.family);
      if (used.has(key)) continue;
      if (s < -2) continue;
      const penalty = diversityPenalty(p, picks);
      if (picks.length > 0 && penalty > 2.4) continue;
      picks.push(p);
      used.add(key);
    }
    if (picks.length < count) {
      for (const { p } of ranked) {
        if (picks.length >= count) break;
        const key = normalize4(p.family);
        if (used.has(key) || reservedNorm.has(key)) continue;
        picks.push(p);
        used.add(key);
      }
    }
    return picks;
  }

  // ../../packages/core/src/aiPairing.ts
  function readEnv(name) {
    var _a;
    try {
      const proc = globalThis.process;
      return (_a = proc == null ? void 0 : proc.env) == null ? void 0 : _a[name];
    } catch (e) {
      return void 0;
    }
  }
  function getAiConfig() {
    const g = globalThis;
    let storageKey = null;
    let storageBase = null;
    let storageModel = null;
    try {
      if (typeof localStorage !== "undefined") {
        storageKey = localStorage.getItem("scafo_ai_key");
        storageBase = localStorage.getItem("scafo_ai_base");
        storageModel = localStorage.getItem("scafo_ai_model");
      }
    } catch (e) {
    }
    const key = g.__SCAFO_AI_KEY__ || storageKey || readEnv("SCAFO_AI_KEY") || readEnv("VITE_SCAFO_AI_KEY") || "";
    if (!key) return null;
    const baseUrl = (g.__SCAFO_AI_BASE__ || storageBase || readEnv("SCAFO_AI_BASE") || readEnv("VITE_SCAFO_AI_BASE") || "https://api.openai.com/v1").replace(/\/$/, "");
    const model = g.__SCAFO_AI_MODEL__ || storageModel || readEnv("SCAFO_AI_MODEL") || readEnv("VITE_SCAFO_AI_MODEL") || "gpt-4o-mini";
    return { key, baseUrl, model };
  }
  async function aiChoosePairing(req) {
    var _a, _b, _c, _d;
    const cfg = getAiConfig();
    if (!cfg) return null;
    const allowed = new Set(req.candidates.map((c) => c.family.toLowerCase()));
    const prompt = [
      "You are an expert typographic pairing director.",
      "Pick the best sub-header and body fonts for the given headline font.",
      "Rules: strong category contrast from the headline, highly readable body,",
      "harmonious mood, production-ready Google-style families only from the candidate list.",
      'Return STRICT JSON only: {"subheader":"Family","body":"Family","rationale":"one sentence"}',
      "",
      `Headline: ${req.mainFamily} (${req.mainCategory}) at ${req.mainSize}px`,
      `Canvas: ${req.canvasWidth}\xD7${req.canvasHeight}`,
      "Candidates:",
      ...req.candidates.map(
        (c) => `- ${c.family} [${c.category}] role=${c.roleHint}`
      )
    ].join("\n");
    try {
      const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${cfg.key}`
        },
        body: JSON.stringify({
          model: cfg.model,
          temperature: 0.2,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: "Return only valid JSON." },
            { role: "user", content: prompt }
          ]
        })
      });
      if (!res.ok) return null;
      const data = await res.json();
      const content = (_c = (_b = (_a = data.choices) == null ? void 0 : _a[0]) == null ? void 0 : _b.message) == null ? void 0 : _c.content;
      if (!content) return null;
      const parsed = JSON.parse(content);
      if (!parsed.subheader || !parsed.body) return null;
      if (!allowed.has(parsed.subheader.toLowerCase())) return null;
      if (!allowed.has(parsed.body.toLowerCase())) return null;
      if (parsed.subheader.toLowerCase() === parsed.body.toLowerCase()) return null;
      return {
        subheader: parsed.subheader,
        body: parsed.body,
        rationale: ((_d = parsed.rationale) == null ? void 0 : _d.trim()) || `AI pairing for ${req.mainFamily}: ${parsed.subheader} + ${parsed.body}.`,
        provider: cfg.model
      };
    } catch (e) {
      return null;
    }
  }
  function profilesToAiCandidates(profiles) {
    return profiles.slice(0, 40).map((p) => ({
      family: p.family,
      category: p.category,
      roleHint: p.category === "display" || p.category === "script" ? "subheader" : p.xHeight === "high" ? "body" : "either"
    }));
  }

  // ../../packages/core/src/webFonts.ts
  var FONTSURCE_LIST = "https://api.fontsource.org/v1/fonts";
  var FONTSURCE_ONE = (id) => `https://api.fontsource.org/v1/fonts/${id}`;
  var listCache = null;
  var listPromise = null;
  function normalize5(s) {
    return s.trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
  }
  function slugify(s) {
    return s.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }
  function editDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost
        );
      }
    }
    return dp[m][n];
  }
  async function fetchWebFontIndex() {
    if (listCache) return listCache;
    if (listPromise) return listPromise;
    listPromise = (async () => {
      const res = await fetch(FONTSURCE_LIST);
      if (!res.ok) throw new Error(`Font web index unavailable (${res.status}).`);
      const data = await res.json();
      listCache = Array.isArray(data) ? data : [];
      return listCache;
    })();
    try {
      return await listPromise;
    } finally {
      listPromise = null;
    }
  }
  async function resolveWebFont(name) {
    const raw = name.trim();
    if (!raw) return null;
    const needle = normalize5(raw);
    const slug = slugify(raw);
    try {
      const direct = await fetch(FONTSURCE_ONE(slug));
      if (direct.ok) {
        const item = await direct.json();
        return toHit(item, "fontsource");
      }
    } catch (e) {
    }
    const index = await fetchWebFontIndex();
    let best = null;
    let bestScore = Infinity;
    for (const item of index) {
      const fam = normalize5(item.family);
      const id = normalize5(item.id);
      if (fam === needle || id === needle) {
        best = item;
        bestScore = 0;
        break;
      }
      if (fam.startsWith(needle) || needle.startsWith(fam)) {
        const d2 = Math.abs(fam.length - needle.length);
        if (d2 < bestScore) {
          best = item;
          bestScore = d2;
        }
        continue;
      }
      if (fam.includes(needle) || needle.includes(fam)) {
        const d2 = Math.abs(fam.length - needle.length) + 1;
        if (d2 < bestScore) {
          best = item;
          bestScore = d2;
        }
        continue;
      }
      const d = editDistance(fam, needle);
      if (d <= 2 && d < bestScore) {
        best = item;
        bestScore = d;
      }
    }
    if (!best || bestScore > 2) return null;
    return toHit(best, "fontsource");
  }
  function toHit(item, source) {
    var _a, _b;
    return {
      id: item.id,
      family: item.family,
      category: item.category || "sans-serif",
      weights: ((_a = item.weights) == null ? void 0 : _a.length) ? item.weights : [400, 700],
      styles: ((_b = item.styles) == null ? void 0 : _b.length) ? item.styles : ["normal"],
      source
    };
  }
  function mapWebCategory(category) {
    const c = category.toLowerCase();
    if (c.includes("mono")) return "mono";
    if (c.includes("hand") || c.includes("script")) return "script";
    if (c.includes("display")) return "display";
    if (c.includes("slab")) return "slab";
    if (c.includes("serif")) return "serif";
    if (c.includes("sans")) return "sans";
    return "sans";
  }
  function inferMoodFromWeb(family, category) {
    const n = family.toLowerCase();
    const moods = [];
    if (/playfair|cormorant|libre|garamond|didot|bodoni|eb garamond/.test(n)) {
      moods.push("editorial", "luxury", "classic");
    } else if (/inter|ibm|source|roboto|noto|work sans|ibm plex/.test(n)) {
      moods.push("tech", "neutral");
    } else if (/poppins|nunito|rounded|fredoka|comfortaa/.test(n)) {
      moods.push("friendly", "playful");
    } else if (/montserrat|raleway|oswald|bebas|anton/.test(n)) {
      moods.push("bold", "neutral");
    } else if (category.includes("serif")) {
      moods.push("editorial", "classic");
    } else if (category.includes("display")) {
      moods.push("bold", "playful");
    } else {
      moods.push("neutral");
    }
    return [...new Set(moods)];
  }
  function webHitToProfile(hit) {
    const category = mapWebCategory(hit.category);
    const styleNames = weightsToStyles(hit.weights, hit.styles);
    return {
      family: hit.family,
      category,
      mood: inferMoodFromWeb(hit.family, hit.category),
      contrast: category.includes("serif") || category === "display" ? "high" : "low",
      xHeight: category.includes("sans") || category === "mono" ? "high" : "medium",
      pairWith: [],
      avoid: [],
      styles: styleNames
    };
  }
  function weightsToStyles(weights, styleKinds) {
    var _a;
    const map = {
      100: "Thin",
      200: "ExtraLight",
      300: "Light",
      400: "Regular",
      500: "Medium",
      600: "SemiBold",
      700: "Bold",
      800: "ExtraBold",
      900: "Black"
    };
    const out = [];
    const hasItalic = styleKinds.some((s) => /italic/i.test(s));
    for (const w of [...weights].sort((a, b) => a - b)) {
      const base = (_a = map[w]) != null ? _a : `W${w}`;
      out.push(base);
      if (hasItalic && (w === 400 || w === 700)) out.push(`${base} Italic`);
    }
    return out.length ? out : ["Regular", "Bold"];
  }
  async function webCompanionPool(mainFamily, preferCategories, limit = 80) {
    const index = await fetchWebFontIndex();
    const mainNorm = normalize5(mainFamily);
    const preferred = new Set(preferCategories.map((c) => c.toLowerCase()));
    const ranked = index.filter((f) => normalize5(f.family) !== mainNorm).map((f) => {
      var _a, _b;
      const cat = (f.category || "").toLowerCase();
      let score = 0;
      if ([...preferred].some((p) => cat.includes(p))) score += 5;
      if (/inter|source|ibm|roboto|noto|lora|merriweather|libre|playfair|cormorant|dm |space |work |nunito|manrope|figtree|outfit|sora|literata|newsreader|fraunces|crimson|cardo|spectral|public sans|atkinson|lexend/.test(
        f.family.toLowerCase()
      )) {
        score += 3;
      }
      if (((_b = (_a = f.weights) == null ? void 0 : _a.length) != null ? _b : 0) >= 4) score += 1;
      return { f, score };
    }).sort((a, b) => b.score - a.score).slice(0, limit).map(({ f }) => webHitToProfile(toHit(f, "fontsource")));
    return ranked;
  }
  function contrastWebCategories(mainCategory) {
    const c = mainCategory.toLowerCase();
    if (c.includes("serif") && !c.includes("sans")) return ["sans-serif"];
    if (c.includes("sans")) return ["serif"];
    if (c.includes("display")) return ["sans-serif", "serif"];
    if (c.includes("hand") || c.includes("script")) return ["sans-serif"];
    if (c.includes("mono")) return ["sans-serif", "serif"];
    return ["sans-serif", "serif"];
  }

  // ../../packages/core/src/intelligent.ts
  function role(family, size, style, category) {
    return { family, size, style, category };
  }
  function normalize6(s) {
    return s.trim().toLowerCase();
  }
  function findProfile(family, pool) {
    const n = normalize6(family);
    return pool.find((p) => normalize6(p.family) === n);
  }
  function toRoles(profiles, size, kind) {
    return profiles.map(
      (p) => role(p.family, size, pickStyle(p, kind), p.category)
    );
  }
  function ensureThree(picks, pool, blocked) {
    const out = [...picks];
    const used = new Set(
      [...out, ...blocked].map((p) => normalize6(p.family))
    );
    for (const p of pool) {
      if (out.length >= 3) break;
      const k = normalize6(p.family);
      if (used.has(k)) continue;
      out.push(p);
      used.add(k);
    }
    return out.slice(0, 3);
  }
  async function analyseIntelligent(input) {
    var _a;
    const mainFont = (input.mainFont || "").trim() || "Inter";
    const mainSize = Number(input.mainSize);
    const canvasWidth = Number(input.canvasWidth);
    const canvasHeight = Number(input.canvasHeight);
    if (!Number.isFinite(mainSize) || mainSize <= 0) {
      throw new Error("Font size must be a positive number.");
    }
    if (!Number.isFinite(canvasWidth) || canvasWidth <= 0) {
      throw new Error("Canvas width must be a positive number.");
    }
    if (!Number.isFinite(canvasHeight) || canvasHeight <= 0) {
      throw new Error("Canvas height must be a positive number.");
    }
    const hierarchy = computeHierarchy(mainSize, canvasWidth, canvasHeight);
    let mainProfile = toProfile(mainFont);
    let resolvedVia = "heuristic";
    let webError = null;
    try {
      const hit = await resolveWebFont(mainFont);
      if (hit) {
        const webProfile = webHitToProfile(hit);
        const catalog = FONT_CATALOG.find(
          (f) => normalize6(f.family) === normalize6(webProfile.family)
        );
        mainProfile = catalog ? __spreadProps(__spreadValues({}, catalog), { family: webProfile.family, styles: webProfile.styles }) : webProfile;
        resolvedVia = catalog ? "catalog" : "web";
      } else if (FONT_CATALOG.some((f) => normalize6(f.family) === normalize6(mainFont))) {
        resolvedVia = "catalog";
      }
    } catch (err) {
      webError = err instanceof Error ? err.message : "Web lookup failed";
    }
    let pool = [...FONT_CATALOG];
    try {
      const webCategory = /serif/i.test(mainProfile.category) && !/sans/i.test(mainProfile.category) ? "serif" : mainProfile.category === "display" ? "display" : mainProfile.category === "script" ? "handwriting" : mainProfile.category === "mono" ? "monospace" : "sans-serif";
      const webPrefer = contrastWebCategories(webCategory);
      const webPool = await webCompanionPool(mainProfile.family, webPrefer, 120);
      const seen = new Set(pool.map((p) => normalize6(p.family)));
      for (const p of webPool) {
        if (seen.has(normalize6(p.family))) continue;
        seen.add(normalize6(p.family));
        pool.push(p);
      }
    } catch (err) {
      webError = webError || (err instanceof Error ? err.message : "Companion web pool failed");
    }
    pool = pool.filter((p) => normalize6(p.family) !== normalize6(mainProfile.family));
    let subOptions = pickTopOptions(mainProfile, pool, "subheader", 3);
    let bodyOptions = pickTopBodyOptions(
      mainProfile,
      pool,
      (_a = subOptions[0]) != null ? _a : pairFonts(mainProfile.family).subheader,
      3,
      subOptions
    );
    let rationale = "";
    let usedAi = false;
    const shortlist = [
      ...subOptions,
      ...bodyOptions,
      ...pickTopOptions(mainProfile, pool, "subheader", 12),
      ...pickTopOptions(mainProfile, pool, "body", 12)
    ];
    const uniqueShortlist = [];
    const seenShort = /* @__PURE__ */ new Set();
    for (const p of shortlist) {
      const k = normalize6(p.family);
      if (seenShort.has(k)) continue;
      seenShort.add(k);
      uniqueShortlist.push(p);
    }
    const ai = await aiChoosePairing({
      mainFamily: mainProfile.family,
      mainCategory: mainProfile.category,
      canvasWidth,
      canvasHeight,
      mainSize,
      candidates: profilesToAiCandidates(uniqueShortlist)
    });
    if (ai) {
      const aiSub = findProfile(ai.subheader, pool);
      const aiBody = findProfile(ai.body, pool);
      if (aiSub && aiBody && normalize6(aiSub.family) !== normalize6(aiBody.family)) {
        const restSubs = pickTopOptions(mainProfile, pool, "subheader", 4, [aiSub]).filter(
          (p) => normalize6(p.family) !== normalize6(aiBody.family)
        );
        subOptions = ensureThree([aiSub, ...restSubs], pool, [aiBody, mainProfile]);
        const restBodies = pickTopBodyOptions(
          mainProfile,
          pool,
          aiSub,
          4,
          subOptions
        ).filter((p) => normalize6(p.family) !== normalize6(aiSub.family));
        bodyOptions = ensureThree([aiBody, ...restBodies], pool, subOptions);
        usedAi = true;
        rationale = `${ai.rationale} (AI \xB7 ${ai.provider}; three curated alternatives each).`;
      }
    }
    if (!usedAi) {
      subOptions = ensureThree(subOptions, pool, [mainProfile]);
      bodyOptions = ensureThree(
        bodyOptions,
        pool,
        [...subOptions, mainProfile]
      );
      const sourceBits = [
        resolvedVia === "web" ? "web font index" : resolvedVia === "catalog" ? "catalog match" : "name heuristic",
        webError ? "offline scoring" : "live web companions"
      ];
      rationale = `${mainProfile.family} \u2192 top sub-headers [${subOptions.map((p) => p.family).join(", ")}] \xB7 top body [${bodyOptions.map((p) => p.family).join(", ")}]. Sources: ${sourceBits.join(" + ")}.`;
    }
    subOptions = ensureThree(subOptions, pool, [mainProfile]);
    bodyOptions = ensureThree(bodyOptions, pool, [...subOptions, mainProfile]);
    const subNorm = new Set(subOptions.map((p) => normalize6(p.family)));
    bodyOptions = bodyOptions.filter((p) => !subNorm.has(normalize6(p.family)));
    bodyOptions = ensureThree(bodyOptions, pool, [...subOptions, mainProfile]);
    const subRoles = toRoles(subOptions, hierarchy.subheader, "subheader");
    const bodyRoles = toRoles(bodyOptions, hierarchy.body, "body");
    return {
      headline: role(
        mainProfile.family,
        hierarchy.headline,
        pickStyle(mainProfile, "headline"),
        mainProfile.category
      ),
      subheader: subRoles[0],
      body: bodyRoles[0],
      subheaderOptions: subRoles,
      bodyOptions: bodyRoles,
      ratio: hierarchy.ratio,
      scaleName: hierarchy.scaleName,
      rationale: `${rationale} Scale: ${hierarchy.scaleName} (${hierarchy.ratio}).`,
      matchedMainFamily: mainProfile.family
    };
  }

  // ../../packages/ui/src/debug/sanitize.ts
  var SECRET_KEY = /^(?:.*(?:api[_-]?key|token|authorization|password|secret|credential).*|vite_scafo_ai_key|scafo_ai_key)$/i;
  var SECRET_VALUE = /(?:sk-[a-zA-Z0-9_-]{8,}|Bearer\s+[A-Za-z0-9._~+/=-]{8,}|AIza[0-9A-Za-z_-]{20,})/g;
  var MAX_STRING = 2e3;
  var MAX_DEPTH = 4;
  var MAX_KEYS = 40;
  function redactString(value) {
    const clipped = value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}\u2026` : value;
    return clipped.replace(SECRET_VALUE, "[redacted]");
  }
  function sanitizeValue(value, depth = 0) {
    if (value == null) return value;
    if (typeof value === "string") return redactString(value);
    if (typeof value === "number" || typeof value === "boolean") return value;
    if (typeof value === "bigint") return String(value);
    if (typeof value === "function" || typeof value === "symbol") return void 0;
    if (depth >= MAX_DEPTH) return "[truncated]";
    if (Array.isArray(value)) {
      return value.slice(0, 20).map((item) => sanitizeValue(item, depth + 1));
    }
    if (typeof value === "object") {
      const out = {};
      let count = 0;
      for (const [key, child] of Object.entries(value)) {
        if (SECRET_KEY.test(key)) {
          out[key] = "[redacted]";
          continue;
        }
        if (count >= MAX_KEYS) {
          out["\u2026"] = "truncated";
          break;
        }
        const cleaned = sanitizeValue(child, depth + 1);
        if (cleaned !== void 0) {
          out[key] = cleaned;
          count += 1;
        }
      }
      return out;
    }
    return String(value);
  }
  function sanitizeState(state) {
    if (!state) return void 0;
    const cleaned = sanitizeValue(state);
    if (!cleaned || typeof cleaned !== "object" || Array.isArray(cleaned)) return void 0;
    return cleaned;
  }
  function sanitizeMessage(message) {
    return redactString(message);
  }
  function errorToParts(err) {
    if (err instanceof Error) {
      return {
        message: sanitizeMessage(err.message || err.name || "Error"),
        stack: err.stack ? sanitizeMessage(err.stack) : void 0
      };
    }
    if (typeof err === "string") {
      return { message: sanitizeMessage(err) };
    }
    try {
      return { message: sanitizeMessage(JSON.stringify(err)) };
    } catch (e) {
      return { message: sanitizeMessage(String(err)) };
    }
  }

  // ../../packages/ui/src/debug/logger.ts
  var RING_SIZE = 100;
  var DEBUG_FLAG = "scafo_debug";
  var seq = 0;
  var ring = [];
  var verbose = false;
  function nextId() {
    seq += 1;
    return `L${Date.now().toString(36)}-${seq}`;
  }
  function push(entry) {
    ring.push(entry);
    if (ring.length > RING_SIZE) ring.shift();
  }
  function shouldMirrorToConsole(level) {
    if (!verbose) return level === "error" || level === "warn";
    return true;
  }
  function mirror(level, message, data) {
    if (!shouldMirrorToConsole(level)) return;
    try {
      const fn = level === "error" ? console.error : level === "warn" ? console.warn : level === "info" ? console.info : console.debug;
      if (data !== void 0) fn(`[Scafo] ${message}`, data);
      else fn(`[Scafo] ${message}`);
    } catch (e) {
    }
  }
  function readVerboseFlag() {
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem(DEBUG_FLAG) === "1") {
        return true;
      }
    } catch (e) {
    }
    try {
      if (typeof location !== "undefined") {
        const q = new URLSearchParams(location.search);
        if (q.get("scafo_debug") === "1" || q.get("debug") === "1") return true;
      }
    } catch (e) {
    }
    return false;
  }
  function setVerbose(on) {
    verbose = on;
    try {
      if (typeof localStorage !== "undefined") {
        if (on) localStorage.setItem(DEBUG_FLAG, "1");
        else localStorage.removeItem(DEBUG_FLAG);
      }
    } catch (e) {
    }
  }
  function isVerbose() {
    return verbose;
  }
  function initVerboseFromEnv() {
    verbose = readVerboseFlag();
  }
  function getRingLogs() {
    return ring.slice();
  }
  function clearRing() {
    ring.length = 0;
  }
  function log(level, message, data) {
    const entry = {
      id: nextId(),
      ts: (/* @__PURE__ */ new Date()).toISOString(),
      level,
      message: sanitizeMessage(message),
      data: data === void 0 ? void 0 : sanitizeValue(data)
    };
    push(entry);
    mirror(level, entry.message, entry.data);
    return entry;
  }
  var debug = (message, data) => log("debug", message, data);
  var info = (message, data) => log("info", message, data);
  var warn = (message, data) => log("warn", message, data);
  var error = (message, data) => log("error", message, data);
  function formatReportText(report) {
    var _a, _b, _c;
    const lines = [
      "=== Scafo debug report ===",
      `generatedAt: ${report.generatedAt}`,
      `host: ${report.host}`,
      `version: ${(_a = report.version) != null ? _a : "(unknown)"}`,
      `lastAction: ${(_b = report.lastAction) != null ? _b : "(none)"}`
    ];
    if (report.lastAnalyseInput) {
      const i = report.lastAnalyseInput;
      lines.push(
        `lastAnalyse: font=${i.mainFont} size=${i.mainSize} canvas=${i.canvasWidth}x${i.canvasHeight}`
      );
    } else {
      lines.push("lastAnalyse: (none)");
    }
    if (report.lastError) {
      const e = report.lastError;
      lines.push("--- last error ---");
      lines.push(`at: ${e.timestamp}`);
      lines.push(`source: ${(_c = e.source) != null ? _c : "unknown"}`);
      lines.push(`host: ${e.host}`);
      lines.push(`message: ${e.message}`);
      if (e.lastAction) lines.push(`action: ${e.lastAction}`);
      if (e.screen) lines.push(`screen: ${e.screen}`);
      if (e.stack) lines.push(`stack:
${e.stack}`);
    } else {
      lines.push("--- last error ---");
      lines.push("(none)");
    }
    lines.push("--- recent logs ---");
    for (const entry of report.recentLogs) {
      const extra = entry.data !== void 0 ? ` ${safeJson(entry.data)}` : "";
      lines.push(`[${entry.ts}] ${entry.level.toUpperCase()} ${entry.message}${extra}`);
    }
    lines.push("=== end ===");
    return lines.join("\n");
  }
  function safeJson(value) {
    try {
      return JSON.stringify(value);
    } catch (e) {
      return String(value);
    }
  }

  // ../../packages/ui/src/debug/storage.ts
  var LAST_ERROR_KEY = "scafo_last_error";
  var LAST_ACTION_KEY = "scafo_last_action";
  function storage() {
    try {
      if (typeof localStorage === "undefined") return null;
      const probe = "__scafo_probe__";
      localStorage.setItem(probe, "1");
      localStorage.removeItem(probe);
      return localStorage;
    } catch (e) {
      try {
        if (typeof sessionStorage === "undefined") return null;
        return sessionStorage;
      } catch (e2) {
        return null;
      }
    }
  }
  function persistLastError(snapshot) {
    try {
      const s = storage();
      if (!s) return;
      s.setItem(LAST_ERROR_KEY, JSON.stringify(snapshot));
    } catch (e) {
    }
  }
  function readLastError() {
    try {
      const s = storage();
      if (!s) return null;
      const raw = s.getItem(LAST_ERROR_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed.message !== "string") return null;
      return __spreadProps(__spreadValues({}, parsed), {
        message: sanitizeMessage(parsed.message),
        stack: parsed.stack ? sanitizeMessage(parsed.stack) : void 0
      });
    } catch (e) {
      return null;
    }
  }
  function clearLastError() {
    var _a;
    try {
      (_a = storage()) == null ? void 0 : _a.removeItem(LAST_ERROR_KEY);
    } catch (e) {
    }
  }
  function persistLastAction(action) {
    try {
      const s = storage();
      if (!s) return;
      if (!action) s.removeItem(LAST_ACTION_KEY);
      else s.setItem(LAST_ACTION_KEY, action.slice(0, 200));
    } catch (e) {
    }
  }
  function readLastAction() {
    var _a, _b;
    try {
      return (_b = (_a = storage()) == null ? void 0 : _a.getItem(LAST_ACTION_KEY)) != null ? _b : null;
    } catch (e) {
      return null;
    }
  }

  // ../../packages/ui/src/debug/safe.ts
  async function safeRun(fn, meta) {
    var _a, _b, _c;
    try {
      const value = await fn();
      return { ok: true, value };
    } catch (err) {
      try {
        error((_b = (_a = meta == null ? void 0 : meta.lastAction) != null ? _a : meta == null ? void 0 : meta.source) != null ? _b : "safeRun failed", {
          source: meta == null ? void 0 : meta.source,
          message: err instanceof Error ? err.message : String(err)
        });
        (_c = meta == null ? void 0 : meta.onError) == null ? void 0 : _c.call(meta, err);
      } catch (e) {
      }
      return { ok: false, error: err };
    }
  }

  // ../../packages/ui/src/debug/overlay.ts
  var reporting = false;
  function showCrashBanner(opts) {
    var _a;
    dismissCrashBanner();
    const banner = document.createElement("div");
    banner.className = "scafo-crash-banner";
    banner.setAttribute("role", "alert");
    banner.dataset.scafoCrash = "true";
    const title = document.createElement("p");
    title.className = "scafo-crash-banner__title";
    title.textContent = opts.recovered ? "Recovered from previous crash" : "Something went wrong";
    const body = document.createElement("p");
    body.className = "scafo-crash-banner__msg";
    body.textContent = opts.message;
    const actions = document.createElement("div");
    actions.className = "scafo-crash-banner__actions";
    const addBtn = (label, className, handler) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = className;
      btn.textContent = label;
      btn.addEventListener("click", () => {
        if (reporting) return;
        reporting = true;
        try {
          void Promise.resolve(handler()).finally(() => {
            reporting = false;
          });
        } catch (e) {
          reporting = false;
        }
      });
      actions.append(btn);
    };
    if (opts.onCopy) {
      addBtn("Copy debug report", "scafo-crash-banner__btn", async () => {
        var _a2;
        await ((_a2 = opts.onCopy) == null ? void 0 : _a2.call(opts));
      });
    }
    if (opts.onRetry) {
      addBtn("Retry last action", "scafo-crash-banner__btn", async () => {
        var _a2;
        dismissCrashBanner();
        await ((_a2 = opts.onRetry) == null ? void 0 : _a2.call(opts));
      });
    }
    if (opts.onReload) {
      addBtn("Reload panel", "scafo-crash-banner__btn", () => {
        var _a2;
        (_a2 = opts.onReload) == null ? void 0 : _a2.call(opts);
      });
    }
    addBtn("Dismiss", "scafo-crash-banner__btn scafo-crash-banner__btn--ghost", () => {
      var _a2;
      dismissCrashBanner();
      (_a2 = opts.onDismiss) == null ? void 0 : _a2.call(opts);
    });
    banner.append(title, body, actions);
    try {
      const mount = (_a = document.querySelector("#app")) != null ? _a : document.body;
      mount.appendChild(banner);
    } catch (e) {
    }
    return banner;
  }
  function dismissCrashBanner() {
    try {
      document.querySelectorAll("[data-scafo-crash]").forEach((el) => el.remove());
    } catch (e) {
    }
  }
  function ensureDebugFooter(opts) {
    const footers = opts.root.querySelectorAll(".footer");
    const cleanups = [];
    footers.forEach((footer) => {
      if (footer.querySelector("[data-scafo-debug-btn]")) return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "footer__debug";
      btn.dataset.scafoDebugBtn = "true";
      btn.textContent = "Debug";
      btn.title = "Copy Scafo debug report";
      btn.hidden = true;
      const onClick = () => {
        void opts.onCopy();
      };
      btn.addEventListener("click", onClick);
      footer.appendChild(btn);
      cleanups.push(() => {
        btn.removeEventListener("click", onClick);
        btn.remove();
      });
    });
    return () => {
      cleanups.forEach((fn) => fn());
    };
  }
  function setDebugFooterVisible(root2, visible) {
    root2.querySelectorAll("[data-scafo-debug-btn]").forEach((btn) => {
      btn.hidden = !visible;
    });
  }

  // ../../packages/ui/src/debug/bootstrap.ts
  var installed = false;
  var reporting2 = false;
  var ctx = { host: "browser" };
  var lastRetry = null;
  var destroyFooter = null;
  var rootEl = null;
  function buildReport() {
    var _a, _b, _c, _d;
    return {
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      host: ctx.host,
      version: ctx.version,
      lastError: readLastError(),
      lastAction: (_b = (_a = ctx.getLastAction) == null ? void 0 : _a.call(ctx)) != null ? _b : readLastAction(),
      lastAnalyseInput: (_d = (_c = ctx.getAnalyseInput) == null ? void 0 : _c.call(ctx)) != null ? _d : null,
      recentLogs: getRingLogs().slice(-100)
    };
  }
  async function copyText(text) {
    var _a;
    try {
      if ((_a = navigator.clipboard) == null ? void 0 : _a.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (e) {
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch (e) {
      return false;
    }
  }
  function exposeGlobal(api) {
    try {
      if (typeof window === "undefined") return;
      window.ScafoDebug = api;
    } catch (e) {
    }
  }
  function makeApi() {
    const api = {
      dump: () => buildReport(),
      copyReport: async () => {
        const text = formatReportText(buildReport());
        const ok = await copyText(text);
        if (ok) info("Debug report copied to clipboard");
        else warn("Could not copy debug report");
        return ok;
      },
      clear: () => {
        clearRing();
        clearLastError();
        lastRetry = null;
        dismissCrashBanner();
        info("Debug buffer cleared");
      },
      enable: () => {
        setVerbose(true);
        if (rootEl) setDebugFooterVisible(rootEl, true);
        info("Verbose debug enabled");
      },
      disable: () => {
        setVerbose(false);
        if (rootEl) setDebugFooterVisible(rootEl, false);
        info("Verbose debug disabled");
      },
      isEnabled: () => isVerbose(),
      getLogs: () => getRingLogs(),
      getLastError: () => readLastError(),
      report: (err, meta) => reportError(err, meta)
    };
    return api;
  }
  function reportError(err, meta) {
    var _a, _b, _c, _d, _e, _f, _g;
    if (reporting2) {
      return {
        message: "Nested report suppressed",
        host: ctx.host,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        source: "unknown"
      };
    }
    reporting2 = true;
    try {
      const parts = errorToParts(err);
      const snapshot = {
        message: parts.message,
        stack: parts.stack,
        host: ctx.host,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        lastAction: (_d = (_c = (_b = meta == null ? void 0 : meta.lastAction) != null ? _b : (_a = ctx.getLastAction) == null ? void 0 : _a.call(ctx)) != null ? _c : readLastAction()) != null ? _d : void 0,
        source: (_e = meta == null ? void 0 : meta.source) != null ? _e : "unknown",
        screen: (_g = meta == null ? void 0 : meta.screen) != null ? _g : (_f = ctx.getScreen) == null ? void 0 : _f.call(ctx)
      };
      if (meta == null ? void 0 : meta.state) {
        sanitizeState(meta.state);
      }
      persistLastError(snapshot);
      if (snapshot.lastAction) persistLastAction(snapshot.lastAction);
      error(snapshot.message, {
        source: snapshot.source,
        stack: snapshot.stack,
        lastAction: snapshot.lastAction
      });
      if (meta == null ? void 0 : meta.retry) lastRetry = meta.retry;
      const isFatal = (meta == null ? void 0 : meta.fatal) === true || (meta == null ? void 0 : meta.source) === "window.onerror" || (meta == null ? void 0 : meta.source) === "unhandledrejection";
      if ((meta == null ? void 0 : meta.fatal) !== false && isFatal) {
        showCrashBanner({
          message: snapshot.message,
          onCopy: async () => {
            await makeApi().copyReport();
          },
          onRetry: lastRetry ? async () => {
            const fn = lastRetry;
            lastRetry = null;
            if (fn) await fn();
          } : void 0,
          onReload: () => {
            try {
              location.reload();
            } catch (e) {
            }
          }
        });
      }
      return snapshot;
    } catch (e) {
      return {
        message: "Report failed",
        host: ctx.host,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        source: "unknown"
      };
    } finally {
      reporting2 = false;
    }
  }
  function onWindowError(message, source, lineno, colno, errorObj) {
    try {
      const msg = typeof message === "string" ? message : (errorObj == null ? void 0 : errorObj.message) || "Uncaught error";
      reportError(errorObj != null ? errorObj : msg, {
        source: "window.onerror",
        fatal: true,
        state: { source, lineno, colno }
      });
    } catch (e) {
    }
    return true;
  }
  function onUnhandledRejection(event) {
    var _a;
    try {
      reportError(event.reason, {
        source: "unhandledrejection",
        fatal: true
      });
      (_a = event.preventDefault) == null ? void 0 : _a.call(event);
    } catch (e) {
    }
  }
  function installDebug(options) {
    var _a;
    initVerboseFromEnv();
    ctx = {
      host: options.host,
      version: options.version,
      getScreen: options.getScreen,
      getAnalyseInput: options.getAnalyseInput,
      getLastAction: options.getLastAction
    };
    rootEl = (_a = options.root) != null ? _a : null;
    const api = makeApi();
    exposeGlobal(api);
    if (!installed && typeof window !== "undefined") {
      installed = true;
      try {
        window.onerror = onWindowError;
        window.addEventListener("unhandledrejection", onUnhandledRejection);
      } catch (e) {
      }
      debug("Debug system installed", { host: options.host, verbose: isVerbose() });
    }
    if (rootEl) {
      destroyFooter == null ? void 0 : destroyFooter();
      destroyFooter = ensureDebugFooter({
        root: rootEl,
        onCopy: async () => {
          await api.copyReport();
        }
      });
      setDebugFooterVisible(rootEl, isVerbose());
    }
    return {
      api,
      setContext(partial) {
        ctx = __spreadValues(__spreadValues({}, ctx), partial);
      },
      setLastAction(action) {
        persistLastAction(action);
      },
      report: reportError,
      showRecoveredBannerIfNeeded() {
        const prev = readLastError();
        if (!prev) return;
        const age = Date.now() - Date.parse(prev.timestamp);
        if (!Number.isFinite(age) || age > 30 * 60 * 1e3) {
          clearLastError();
          return;
        }
        showCrashBanner({
          message: sanitizeMessage(prev.message),
          recovered: true,
          onCopy: async () => {
            await api.copyReport();
          },
          onRetry: lastRetry ? async () => {
            const fn = lastRetry;
            lastRetry = null;
            if (fn) await fn();
          } : void 0,
          onDismiss: () => {
            clearLastError();
          }
        });
      },
      destroy() {
        try {
          if (typeof window !== "undefined") {
            if (window.onerror === onWindowError) window.onerror = null;
            window.removeEventListener("unhandledrejection", onUnhandledRejection);
          }
        } catch (e) {
        }
        destroyFooter == null ? void 0 : destroyFooter();
        destroyFooter = null;
        dismissCrashBanner();
        installed = false;
        rootEl = null;
      }
    };
  }

  // ../../packages/ui/src/app.ts
  var loadedFonts = /* @__PURE__ */ new Set();
  var MIN_LOADING_MS = 900;
  function qs(root2, sel) {
    const el = root2.querySelector(sel);
    if (!el) throw new Error(`Missing element: ${sel}`);
    return el;
  }
  function wait(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }
  function waitForPaint() {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => resolve());
      });
    });
  }
  function loadGoogleFont(family) {
    const name = family.trim();
    if (!name || loadedFonts.has(name)) return;
    loadedFonts.add(name);
    const id = `scafo-font-${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
    if (document.getElementById(id)) return;
    try {
      const link = document.createElement("link");
      link.id = id;
      link.rel = "stylesheet";
      link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name).replace(/%20/g, "+")}:wght@400;500;600;700;800&display=swap`;
      link.onerror = () => {
        warn("Google Font stylesheet failed to load", { family: name });
      };
      document.head.appendChild(link);
    } catch (err) {
      warn("Font link inject failed", {
        family: name,
        message: err instanceof Error ? err.message : String(err)
      });
    }
  }
  function mountScafoUi(root2, handlers, options = {}) {
    var _a, _b;
    let current = null;
    let messageTimer = null;
    let analyseEpoch = 0;
    let subIndex = 0;
    let bodyIndex = 0;
    let activeScreen = "input";
    let lastAction = null;
    let lastAnalyseInput = null;
    const host = (_a = options.host) != null ? _a : "browser";
    let debugHandle = null;
    try {
      debugHandle = installDebug({
        host,
        version: (_b = options.version) != null ? _b : "0.1.0",
        root: root2,
        getScreen: () => activeScreen,
        getAnalyseInput: () => lastAnalyseInput,
        getLastAction: () => lastAction
      });
    } catch (e) {
    }
    function setAction(action) {
      lastAction = action;
      debugHandle == null ? void 0 : debugHandle.setLastAction(action);
    }
    const inputScreen = qs(root2, '[data-screen="input"]');
    const loadingScreen = qs(root2, '[data-screen="loading"]');
    const resultScreen = qs(root2, '[data-screen="result"]');
    const errorEl = qs(root2, "[data-error]");
    const actionsEl = qs(root2, "[data-actions]");
    const messageEl = qs(root2, "[data-message]");
    const resultSide = qs(root2, "[data-result-side]");
    const subPicks = qs(root2, '[data-picks="sub"]');
    const bodyPicks = qs(root2, '[data-picks="body"]');
    const mainFont = qs(root2, "#mainFont");
    const mainSize = qs(root2, "#mainSize");
    const canvasW = qs(root2, "#canvasW");
    const canvasH = qs(root2, "#canvasH");
    const out = {
      subSize: qs(root2, '[data-out="subSize"]'),
      bodySize: qs(root2, '[data-out="bodySize"]')
    };
    function showResultIdle() {
      if (messageTimer) {
        clearTimeout(messageTimer);
        messageTimer = null;
      }
      resultSide.classList.remove("is-screenshot");
      actionsEl.hidden = false;
      messageEl.hidden = true;
    }
    function showScreen(screen) {
      if (screen !== "loading") analyseEpoch += 1;
      activeScreen = screen;
      inputScreen.classList.toggle("is-active", screen === "input");
      loadingScreen.classList.toggle("is-active", screen === "loading");
      resultScreen.classList.toggle("is-active", screen === "result");
      if (screen === "result") {
        showResultIdle();
        return;
      }
      if (messageTimer) {
        clearTimeout(messageTimer);
        messageTimer = null;
      }
      resultSide.classList.remove("is-screenshot");
      messageEl.hidden = true;
      actionsEl.hidden = false;
    }
    function showError(message) {
      if (!message) {
        errorEl.hidden = true;
        errorEl.textContent = "";
        return;
      }
      errorEl.hidden = false;
      errorEl.textContent = message;
    }
    function showScreenshotMessage(ms = 2200) {
      resultSide.classList.add("is-screenshot");
      actionsEl.hidden = true;
      messageEl.hidden = false;
      if (messageTimer) clearTimeout(messageTimer);
      messageTimer = setTimeout(() => {
        resultSide.classList.remove("is-screenshot");
        actionsEl.hidden = false;
        messageEl.hidden = true;
        messageTimer = null;
      }, ms);
    }
    function applySelection() {
      var _a2, _b2, _c, _d;
      if (!current) return;
      const sub = (_b2 = (_a2 = current.subheaderOptions[subIndex]) != null ? _a2 : current.subheaderOptions[0]) != null ? _b2 : current.subheader;
      const body = (_d = (_c = current.bodyOptions[bodyIndex]) != null ? _c : current.bodyOptions[0]) != null ? _d : current.body;
      current = __spreadProps(__spreadValues({}, current), {
        subheader: sub,
        body
      });
      renderPickList(subPicks, current.subheaderOptions, subIndex, "sub");
      renderPickList(bodyPicks, current.bodyOptions, bodyIndex, "body");
    }
    function renderPickList(list, options2, active, role2) {
      list.innerHTML = "";
      options2.slice(0, 3).forEach((opt, i) => {
        loadGoogleFont(opt.family);
        const li = document.createElement("li");
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = `font-pick${i === active ? " is-active" : ""}`;
        btn.dataset.role = role2;
        btn.dataset.index = String(i);
        btn.setAttribute("aria-pressed", i === active ? "true" : "false");
        btn.title = `Use ${opt.family}`;
        const rank = document.createElement("span");
        rank.className = "font-pick__rank";
        rank.textContent = `${i + 1}`;
        const name = document.createElement("span");
        name.className = "font-pick__name";
        name.textContent = opt.family;
        name.style.fontFamily = `"${opt.family}", Georgia, serif`;
        btn.append(rank, name);
        li.append(btn);
        list.append(li);
      });
    }
    function paintResult(result) {
      current = result;
      subIndex = 0;
      bodyIndex = 0;
      loadGoogleFont(result.headline.family);
      out.subSize.textContent = `${result.subheader.size}`;
      out.bodySize.textContent = `${result.body.size}`;
      applySelection();
    }
    function readInput() {
      return {
        mainFont: mainFont.value.trim(),
        mainSize: Number(mainSize.value),
        canvasWidth: Number(canvasW.value),
        canvasHeight: Number(canvasH.value)
      };
    }
    async function onAnalyse() {
      var _a2;
      showError(null);
      const input = readInput();
      if (!input.mainFont) {
        showError("Insert a main font name.");
        return;
      }
      if (!Number.isFinite(input.mainSize) || input.mainSize <= 0) {
        showError("Enter a valid main text size.");
        return;
      }
      if (!Number.isFinite(input.canvasWidth) || input.canvasWidth <= 0) {
        showError("Enter a valid canvas width.");
        return;
      }
      if (!Number.isFinite(input.canvasHeight) || input.canvasHeight <= 0) {
        showError("Enter a valid canvas height.");
        return;
      }
      setAction("analyse");
      lastAnalyseInput = __spreadValues({}, input);
      const epoch = ++analyseEpoch;
      showScreen("loading");
      await waitForPaint();
      const started = Date.now();
      const run = await safeRun(() => analyseIntelligent(input), {
        source: "analyse",
        lastAction: "analyse",
        screen: "loading"
      });
      if (!run.ok) {
        if (epoch !== analyseEpoch) return;
        showScreen("input");
        const msg = run.error instanceof Error ? run.error.message : "Could not analyse.";
        showError(msg);
        debugHandle == null ? void 0 : debugHandle.report(run.error, {
          source: "analyse",
          lastAction: "analyse",
          fatal: false,
          retry: () => onAnalyse()
        });
        return;
      }
      const elapsed = Date.now() - started;
      if (elapsed < MIN_LOADING_MS) await wait(MIN_LOADING_MS - elapsed);
      if (epoch !== analyseEpoch) return;
      paintResult(run.value);
      showScreen("result");
      info("Analyse complete", {
        main: (_a2 = run.value.matchedMainFamily) != null ? _a2 : input.mainFont,
        sub: run.value.subheader.family,
        body: run.value.body.family
      });
    }
    async function onScreenshot() {
      if (!current) return;
      setAction("screenshot");
      applySelection();
      showScreenshotMessage();
      const input = readInput();
      const result = current;
      const run = await safeRun(() => handlers.onScreenshot(result, input), {
        source: "export",
        lastAction: "screenshot",
        screen: "result",
        onError: (err) => {
          debugHandle == null ? void 0 : debugHandle.report(err, {
            source: "export",
            lastAction: "screenshot",
            fatal: false,
            retry: () => onScreenshot()
          });
          showError(
            err instanceof Error ? err.message : "Screenshot / export failed."
          );
        }
      });
      if (run.ok) {
        debug("Screenshot handler finished");
      }
    }
    function onClick(event) {
      var _a2;
      const target = event.target;
      if (!target) return;
      const pick = target.closest(".font-pick");
      if ((pick == null ? void 0 : pick.dataset.role) && pick.dataset.index != null) {
        const idx = Number(pick.dataset.index);
        if (!Number.isFinite(idx)) return;
        if (pick.dataset.role === "sub") subIndex = idx;
        if (pick.dataset.role === "body") bodyIndex = idx;
        applySelection();
        return;
      }
      const action = (_a2 = target.closest("[data-action]")) == null ? void 0 : _a2.dataset.action;
      if (!action) return;
      if (action === "analyse") void onAnalyse();
      if (action === "back") showScreen("input");
      if (action === "screenshot") void onScreenshot();
    }
    function onKeydown(event) {
      if (event.key === "Enter" && inputScreen.classList.contains("is-active")) {
        void onAnalyse();
      }
    }
    root2.addEventListener("click", onClick);
    root2.addEventListener("keydown", onKeydown);
    messageEl.hidden = true;
    showScreen("input");
    try {
      debugHandle == null ? void 0 : debugHandle.showRecoveredBannerIfNeeded();
    } catch (e) {
    }
    return {
      destroy() {
        root2.removeEventListener("click", onClick);
        root2.removeEventListener("keydown", onKeydown);
        if (messageTimer) clearTimeout(messageTimer);
        analyseEpoch += 1;
        try {
          debugHandle == null ? void 0 : debugHandle.destroy();
        } catch (e) {
        }
        debugHandle = null;
      },
      getResult: () => current,
      showScreen,
      showScreenshotMessage
    };
  }

  // ../../packages/ui/src/markup.ts
  function pluginMarkup(assets) {
    return `
    <div id="app">
      <section class="screen is-active" data-screen="input" aria-label="Input">
        <div class="shell">
          <header class="brand">
            <div class="brand-row">
              <h1 class="brand-title">Scafo.</h1>
              <p class="brand-tag">
                <span class="brand-tag__line">Font pairing &amp; Scaling</span>
                <span class="brand-tag__line">made easy.</span>
              </p>
            </div>
            <hr class="brand-rule" />
          </header>

          <div class="input-panel">
            <div class="field-grid">
              <label class="field field--font">
                <img class="field__icon field__icon--font" src="${assets.font}" alt="" width="12" height="10" />
                <input id="mainFont" type="text" placeholder="Insert main font name" autocomplete="off" spellcheck="false" />
              </label>
              <label class="field">
                <img class="field__icon" src="${assets.type}" alt="" width="14" height="14" />
                <input id="mainSize" type="number" min="8" step="1" placeholder="Font size of the main text" />
              </label>
              <label class="field">
                <img class="field__icon" src="${assets.width}" alt="" width="14" height="14" />
                <input id="canvasW" type="number" min="1" step="1" placeholder="W of the canvas" />
              </label>
              <label class="field field--height">
                <img class="field__icon field__icon--height" src="${assets.height}" alt="" width="12" height="12" />
                <input id="canvasH" type="number" min="1" step="1" placeholder="H of the canvas" />
              </label>
            </div>
            <button class="btn btn--analyse" type="button" data-action="analyse">Analyse</button>
            <footer class="footer">
              <p class="footer__by">Designed by Akshay S Dev</p>
              <p class="footer__copy">COPYRIGHTS \xA9 ALL RESERVED 2026</p>
            </footer>
            <p class="error" data-error hidden></p>
          </div>
        </div>
      </section>

      <section class="screen screen--loading" data-screen="loading" aria-label="Loading" aria-busy="true">
        <div class="shell shell--loading">
          <header class="brand brand--loading">
            <div class="brand-row">
              <h1 class="brand-title">Scafo.</h1>
              <p class="brand-tag">
                <span class="brand-tag__line">Font pairing &amp; Scaling</span>
                <span class="brand-tag__line">made easy.</span>
              </p>
            </div>
            <hr class="brand-rule brand-rule--pulse" />
          </header>
        </div>
      </section>

      <section class="screen screen--result" data-screen="result" aria-label="Result">
        <div class="shell shell--result">
          <header class="brand">
            <div class="brand-row">
              <h1 class="brand-title">Scafo.</h1>
              <p class="brand-tag">
                <span class="brand-tag__line">Font pairing &amp; Scaling</span>
                <span class="brand-tag__line">made easy.</span>
              </p>
            </div>
            <hr class="brand-rule" />
          </header>

          <div class="result-grid">
            <div class="result-fonts">
              <div class="result-box">
                <img class="result-box__icon" src="${assets.font}" alt="" width="12" height="10" />
                <div class="result-box__stack">
                  <p class="result-box__label">Best font for sub header</p>
                  <ol class="font-picks" data-picks="sub" aria-label="Sub header font options"></ol>
                </div>
              </div>
              <div class="result-box">
                <img class="result-box__icon" src="${assets.font}" alt="" width="12" height="10" />
                <div class="result-box__stack">
                  <p class="result-box__label">Best font for body</p>
                  <ol class="font-picks" data-picks="body" aria-label="Body font options"></ol>
                </div>
              </div>
            </div>

            <div class="result-side" data-result-side>
              <div class="size-row">
                <div class="size-box">
                  <img class="size-box__icon" src="${assets.type}" alt="" width="14" height="14" />
                  <p class="size-box__label">Font size for sub header</p>
                  <p class="size-box__value" data-out="subSize">\u2014</p>
                </div>
                <div class="size-box">
                  <img class="size-box__icon" src="${assets.type}" alt="" width="14" height="14" />
                  <p class="size-box__label">Font size for<br />body</p>
                  <p class="size-box__value" data-out="bodySize">\u2014</p>
                </div>
              </div>

              <div class="action-stack" data-actions>
                <button class="btn btn--block" type="button" data-action="screenshot">Take a screenshot.</button>
                <button class="btn btn--block" type="button" data-action="back">Back</button>
              </div>
              <div class="message-box" data-message hidden>
                <p>One font in. Perfect hierarchy out.</p>
              </div>
            </div>
          </div>

          <footer class="footer">
            <p class="footer__by">Designed by Akshay S Dev</p>
            <p class="footer__copy">COPYRIGHTS \xA9 ALL RESERVED 2026</p>
          </footer>
        </div>
      </section>
    </div>
  `;
  }

  // ../../packages/ui/src/save.ts
  async function savePng(blob, suggestedName = "scafo-hierarchy.png") {
    const w = window;
    if (typeof w.showSaveFilePicker === "function") {
      try {
        const handle = await w.showSaveFilePicker({
          suggestedName,
          types: [
            {
              description: "PNG image",
              accept: { "image/png": [".png"] }
            }
          ]
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        return "picker";
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") {
          throw err;
        }
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = suggestedName;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    return "download";
  }

  // assets/icon-font.png
  var icon_font_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAADdgAAA3YBfdWCzAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAApYSURBVHic7Z3r81ZVFcc/XwTlJhFj5oW4CPziN+KM6CSNaAOVglrUyHTx1iiODiMRaX9ErzK7iOMtGa0pkRdMmRo1hg3p6JA0OjpCQMolS0IlCDGQ1Yt9Ygx+55znec7e+9yezztlP/u7YK2zzt777L2XzIw+7WVY2Qb0KZd+ALScfgC0nH4AtJx+ALSc4WUbEBtJvwDOSPnjXWZ2fUx7ykZtmgZKmg88ndNsnpk9E8OeKtC2V8CKDtp8J7gVFaI1GUDSVGAr+UFvwKCZbQ5vVfm0KQMso7O/r4DbA9tSGVqRASSNAXYB4zv8yXvAJDP7ZzirqkFbMsANdO58gFHAbYFsqRRtyQCvAoNd/uwtYLKZHQpgUmVofAaQdBndOx/gdKDxawKNDwDgWwV+e4ckebOkgjQ6ACRNA64s0MUgcIUncypJowMAWE7xv2OjF4YaOwiUNBbYDYzz0N1sM/uzh34qR5MzwI34cT40OAs0MgMkA7fXgAFPXR4GpprZbk/9VYamZoAF+HM+wAiKzSYqS1MzwJPAQs/dvgt8wswOeO63VBqXASQN4DKAb8YDNwfot1QaFwC4qV+oxZsVkk4K1HcpNCoAJI3Djf5DMRW4OmD/0WlUAABLgLGBNe4I3H9UGjMIlDQM2AJMiyA318yejaATnCZlgCuJ43xo0MJQkzLAOuCySHJHgQEz2xZJLxiNyACSBonnfHD/bt+OqBeMRgQA5azS3STpoyXoeqX2ASBpPG7PX2zGAEtL0PVK7QMAtzo3piTt5ZJOLknbC7UOgGTqt6xEE84ErilRvzC1DgBgEW51rkxqPSWsewDkDf5eiWDDecnO41pS2wCQNAuYn9FkH25D578jmFPbLFDbACD/6X/QzHYCD0WwZUESkLWjliuBkibgzvqNSmlyFJhhZtuTreFbCB/sD5nZksAa3qlrBriFdOcDPG5m2wGS5dq1EWy6TlLazSOVpXYBkGzIyDu4+cPj/vt7gcz5MCcD34yg45XavQIkLQbWZDR5xcxOeB9Leg74dDDDHG/j9g0eDKzjjdplAPIHfz9K+f8xssAEwu5I8k6tMoCk84FNGU3eASYO9QQmr46/EH7haCvwSTM7GljHC3XLAHlP/wNp6dfMPgDu8m/SCUzHrVDWgtpkAEmnATuBkSlNPgCmmdkbGX2MTfro5raQXthgZpcG1vBCnTLAraQ7H+CXWc4HSA513OvVqqG5RNJFEXQKU4sMIGk48Dpwdkaz+Wa2voO+zkr6GuHDtgxWm9nXAmsUpi4ZYDHZzn+pE+cDmNnfgJ/7MCqHxZImR9ApRF0CIG/wd/zCTx539mpIF5xEDfYNVv4VIOlCYGNGk724xZf3uuz3t8Dni9jWAftxtu0LrNMzdcgAeU///d06PyHGwtCpuMFrZal0BpB0Om7alrbv7ghwTvLZt9u+BbwMnNu7hR2xC3e5xJHAOj1R9QywlHTnA6ztxfkA5iI/xlhgIvDVCDo9UdkMIGkE8AZu42Ual5rZhgIapyQaH++1jw550cwuDKzRE1XOAF8h2/mbijgfwMzeB35cpI8OuUDSvAg6XVPlAPA99UvjHtzt4KGp5L7BSgaApDnAnIwme/C0mGNme4FVPvrK4SpJMyPodEUlA4D8p/++JH374vu4fYQhqWQhisoNAiWdiRuYpa3VHwGm+L6zT9Ja4Es++xyCQ7hCFHsC63RMFTPAUrI/1KwJdGFjjIWhkVSsEEWlMkBy0HIn7q7+NC42s+cC6b8AfCpE3x9iDy4LVKIQRdUywNfJdv7GUM5PiJEFPkY5x9mHpGoBEGvql8Ya3PgjNJUpRFGZAJB0MZC1WvYP4NGQNiT7Bn8QUiNhJsUKWXijMgFA/tN/r5n9J4IdD+AOloamEgtDlQgASWfjdv2kcRi3YhccM9sP3B9Bar6k2RF0MqlEAOCmRlmVzFeb2d9jGYN7DcT4fFt6Fih9GihpJG7qd1pGszlm9kIkkwCQ9FPgusAyh3H7GXYF1kmlChngGrKd/3xs5yfE2CtQeiGKKgRA2VO/ITGzF4HfR5C6VdKpEXSGpNQAkPQZ4PyMJm8Cj0UyZyhiLAx9hBILUZSdAfKe/nvM7HAUS4bmCVzxqdCUVoiitACQNAn4ckaT94lzjCuViPsGp5A9DQ5GmRngNtzhiTQeNbO3YhmTwSO4DzihKWVKWEoASBqFu+cni1IGf8eTfLW7O4LURZIuiaDzf5SVAa7H3aaRxrNm9qdYxnTAStxmjtBEzwJlBUAlp35pJDt4Ho4gtUjS9Ag6x4i+EihpPvB0VNF6sdLMol2AXUYAxNh7V2cO4g6Uvh1DLOorQNJU4IsxNWvIaCIWoog9BlhWgmYdiVaIIpozJI2hgbV3A3EGcG0MoZhP4w2Ev52rSUSZEsYMgFI/e9aQWZIuDy0SZRaQVNRYl9HkTeC+4Ib45XZgXGCNdWa2IKRA1jYsn+Te72tm341iiSeSSydDp+nLJZ1nZi+HEgieAToo2HAId7/v3qCGeCb5mrmN8A/RKjO7KVTnMcYAy3N0flY35wOY2Q7ibFa5NjkwG4SgAZCkybzordS6f5fE2CsQtBBF6AxwI9kDpfVm9lJgG4JhZhuBZyJILZU0OkTHwQIgOfu2PKdZnZ/+/xGrEEWQcUCwQaCkhcCTGU1eB6Yn5/FqSxLorwEDgaW2AQO+C1GEfAWsyPnzu+vufIi6b3AaAb6iBskAkgZwT0XaEeiDuKnfO97FSyDZ4raD7AMuPvijmXndNhYqAywn3fkADzfF+QDJXcUrI0jNTW5Q84b3DCBpHLAbGJvR7Fwze9WrcMkk9xrvAE4JLPWYmXm7ejZEBlhCtvN/1zTnAyRb2B+JIHW1pCm+OvMaAJKGkb9oEeMGjrK4Ewj9dc1rIQqvrwBJXwB+ldEkyFSmSkj6NeGvfzmA2zf4btGOfL8COvnq11jnJ8RYGBqLp0IU3jKApEEg692+Hzf1+5cXwQojaRPZp559sAt3uUShw7M+M0De07+qDc5PiJEFJgKFy9J5yQCSxuMickxKEwNmmtmWwmI1ICl28VeyS935YJOZXVCkA18Z4GbSnQ/wVFucD5Ck5RgfumZL+myRDgpngGTqt5XsqtwLzew3hYRqRpIVd5K9JuKDJ8zsql5/7CMDLCLb+ZvJ3hDaSJIp2oMRpK5IBuA94SMAck/6Wtl30ZXHXbiq5iEpVIii0CtA0ixc7b009uGmfgd6Fqk5klbjCmCF5BAwuZcbVYpmgLyn/ydtdn5CpQtR9JwBJE3ATf1GpTQ5Cswws+09CTQISRuAuYFleipEUSQD3EK68wEe7zv/GLEKUXyj2x/1lAGSO+22A5Mymn3OzPo3gXBsqrwZCH39y2ZgsJtBt4D1PQiNJru2jgF/6KHfEzsym+ejH99IWt/lT2YAZwUw5Xiep4sLrUT479eFMLNKlFY5HkmV/nfrlP5tHS2nHwAtpx8ALacfAC2nHwAtZzhxTrc2kUb8u5VeNKpPufRfAS2nHwAtpx8ALacfAC2nHwAt57/JZgrFbgOG6wAAAABJRU5ErkJggg==";

  // assets/icon-type.png
  var icon_type_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAACxQAAAsUBidZ/7wAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJ3SURBVHic7dzBbdtAEEbhP4ELcSfedJJOsunEpdCdsBPn4qtmhd2IpvjeB/BEjKzYDyaooZPUepLP4tA5VD+jXg3+fPQ707kZAJwBwBkAnAHAGQDcj9S3CS3J22C+mm3F+errvib5XZx/T7JfaDapvx/b13FLdUv+MZgt7yFHR6UvzLbBbLvYbAazfWG2PLwEwBkAnAHAGQCcAcAZgCRJkiRJHNU6N1lb6Y5mdb8t9Uq3L8yWeh63Dva4/+iD7/X0rJ8EwhkAnAHAGQCcAcAZANzL4HzP+BZE32/0ec5N/gaAMwA4A4AzADgDgDMAuNFtYMv8OljH6cW5LcU6+J4A/kx+YR2n+hklRQBeAuAMAM4A4AwAzgDgDECX0/K4p3PbYf+Kg/gbAM4A4AwAzgDgDADOAOBG28DXr+OW7X+9ES1pxbk99X9SXeqZ/+vg79LC+xzAvw7WHAOAMwA4A4AzADgDgBt9DvAe7/Wfwa/i3F4NjgLYRy+gU9hmB70EwBkAnAHAGQCcAcC5Dr6GVpzb4zrYdfAtXgLgDADOAOAMAM4A4AwAznXwNbgOhttmB70EwBkAnAHAGQCcAcAZANwogJ7nWwcTuQ7WHAOAMwA4A4AzADgDgBttA7cj3oSW/S3ObUe9ibNo4T0WPs1LAJwBwBkAnAHAGQCcAcC5Dr4G18GaYwBwBgBnAHAGAGcAcFdcB++p16Orr31GroMlSZIkSfdaeUq20hdm22C2XWw2g9m+MFsefhIIZwBwBgBnAHAGAGcAcC+pV4ktydvka2+Tc8l4pbtfbDaD2W0wW/lYme/xsfBn4GPhmmMAcAYAZwBwBgBnAHD/ACHQ6Sb4Jw06AAAAAElFTkSuQmCC";

  // assets/icon-width.png
  var icon_width_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAADdgAAA3YBfdWCzAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAQYSURBVHic7Z2xbhVHFIa/gxCVJSokP4ALiAQNRZoUhAalN0IRT4BoeAeeAUGXF0iTCqVIgmSkUNPQ8AZUSKSJLYbi+iKwjZmdu7tn9v7/J51uxzPj/9sZ++6de6OUgtHlQvYATC4WQBwLII4FEMcCiGMBxLEA4lgAcSyAOBZAHAsgjgUQxwKIYwHEsQDiWABxLIA4FkAcCyCOBRDHAohjAcSxAOJYAHEsgDgWQJwAbtVcWEp5MelIzKhExK2q64Cqw4GllNhkQGZeIqIqV28B4lgAcSyAOBZAHAsgjgUQxwKIYwHEsQDidCNARFyJiN8i4nL2WKYiInaP57iTPZY1F7MHAKvwgb+A68C1iLhTSnmfPKxRiYhd4B/gKrAXEb+UUj4kDyt/BTgRPsCPwJ/btBKcCB/gJ+B5DytBqgBnhL9mayQ4I/w1XUiQJsA54a9ZvATnhL+mCwlKTZVSGKuAK8Dryr5fAZfH7H+OAnaBN5VzPAB2Ru6/KtfZBRgY/iIlGBj+JBLU9jvrFlCx7H+L68AP449oMm4CewPbpG0Hs6wAtN35BfgPuJ19VzfMdx84bJjvKCvBgP6mF0At/B4k6EYA1fCzJehCAPXwMyVIF8Dh50qQKoDDz5cgTQCH34cEKQI4/H4kmF0Ah9+XBLMK4PD7k2A2ARx+nxLMIoDD71eC2p/RfDp4gwc7AI+BvxvabTP7wMOGdi+BU28vqz0dDA0rAO13vmuaOrUSDGg7TACH3219JcEkAjj87uuzBAPaVF/o8JdRB8BO7fXVfwSyCv9G5bUmlxdUfvbTkLeEPaNeFpPHEfBkSIOqpeJ4X3kAfKxt45q9DoH9qf8LsAR91ufwJ38l0BJ0V1+FP0SApsOhpZSnEQGrvabl8wP/Bf5v6XuL2WH1dvKhHAG/llJ+b+m0+XTwhhK8A+6WUiwBcHwW4HlD043CXzN4CxhpO/gDuJT9ICa7WN35Bw2/v1PL/iwvBVuC/sOfXQBL0Ff4KQJYgn7CTxPAEvQRfqoAliA//HQBLEFu+F0IYAnywu9GAEuQE35XAihLkBV+dwIoSpAZfpcCKEmQHX63AmwgwRELOkgC3MsMv2sBGiQ4Au5nh9owx0dZ4XcvwAAJFhn+QAlGD38RAlRIsOjwKyWYJPzFCHCOBFsR/nckmCz8RQlwhgRbFf43JJg0/MUJ8IUEh9sY/gkJJg9/iABdfXl0ROyVUt5O3U8mc82x9nh4VwKY8fC3h5sqLIA4FkAcCyCOBRDHAohjAcSxAOJYAHEuAj9nD8JMQlWucfzgwIjiLUAcCyCOBRDHAohjAcSxAOJYAHEsgDgWQBwLII4FEMcCiGMBxLEA4lgAcSyAOBZAHAsgjgUQxwKIYwHEsQDiWABxLIA4FkAcCyDOJ4T+X68SxDNLAAAAAElFTkSuQmCC";

  // assets/icon-height.png
  var icon_height_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAADdgAAA3YBfdWCzAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAARNSURBVHic7d2xilVXFMbx/9JgIQGrvEHaVBYiWDhJJYFUNiGPIAQsIvgWQhAttQoh6SSEBEWLtKnSWPgAQtqUgZViZoeTieOcc885e++1v/WvR8/C7+e9MNxhzN2plZndBF5We2DMjtz9Va2HXaj1oKzPEoB4CUC8BCBeAhAvAYiXAMRLAOIlAPGs5ncCe8rMPgSeAQ/d/cfW97Tqg9YHtOhk/J+BG8ANM0MVgdxbwKnx4fg/wXdmdrvdVe2SAvCO8UuyCGQAvGf8kiQCCQAzxi/JIRgewILxS1IIhgZwwPglGQTDAlgxfkkCwZAANhi/NDyC4QBsOH5paARDAdhh/NKwCIYBsOP4pSERDAGgwvil4RCEB1Bx/NJQCEIDaDB+aRgEYQE0HL80BIKQADoYvxQeQTgAHY1fCo0gFIAV4/8NPJz5tb8Dvy38+8MiCANg5fhfAnM/8vUXcAsRBCEArB1/6ef93F0GQfcAao9fUkHQNYBW45cUEHQLoPX4pdERdAsA+JbG45c2QPDxlvdsWc8A7gOvF3z9LuOXViD4xt3f7HDSJnULwN3fAkfMQ7Dr+JObliK46+4Pdjxpdd0CgNkIqow/uWkugu7Hh84BwLkIqo4/uek8BCHGhwAA4EwETcaf3HQWgjDjQxAA8D8ETcef3HQaQajxIdiPh7v7WzM7Aq66+0+t74FjBGZ2C/jc3b9vfc/SQgGAf18Juhi/dPJKEG58CPQWkO1TAhAvAYiXAMRLAOIlAPESgHgJQLwEIF4CEC8BiJcAxEsA4iUA8RKAeAlAvAQgXgIQLwGIlwDESwDiJQDxEoB4CUC8BCBeAhAvAYiXAMRLAOIlAPESgHgJQLwEIF4CEC8BiJcAxEsA4iUA8RKAeAlAvAQgXjgAZnbFzK63vmOamV0ys09b33FIoQCY2RXgF+B5L//gZnYJ+AH41cy+an3P0sIAmIx/DbgMPGuNYDL+F8BF4Gk0BCEAnBq/1BTBqfFL4RB0D+CM8UtNEJwxfikUgq4BnDN+qSqCc8YvhUHQLYCZ45eqIJg5fikEgm4BAA+YN35pVwQLxy9dBJ7kL448rHvAHwv/zC4IDhwfwIGv8xdHHpC7/wl8RmMEK8e/4+6Ptrhjr7oFAO0RjD4+dA4A2iFQGB8CAID6CFTGhyAAYD0CYC4CmfEBzN1b37AoM/sIeAF80vqWSSHHh0CvAKUVrwR7FXZ8CAgAukIQenwICgC6QBB+fAgMAJoiGGJ8CA4AmiAYZnwYAABURTDU+DAIAKiCYLjxYSAAsCuCIceHwQDALgiGHR8GBACbIhh6fBgUAGyCYPjxYWAAsAqBxPgwOAA4CIHM+CAAABYhkBofRADALARy44MQAHgvAsnxQQwAvBOB7PgQ8BNBW3XyyaLnwGPV8aEyADO7Cbys9sCYHbn7q1oPk3sLyP5bAhAvAYiXAMRLAOIlAPESgHgJQLwEIN4/qL8qJUXqRLEAAAAASUVORK5CYII=";

  // src/panel.ts
  var root = document.querySelector("#root");
  if (!root) throw new Error("#root missing");
  root.innerHTML = pluginMarkup({
    font: icon_font_default,
    type: icon_type_default,
    width: icon_width_default,
    height: icon_height_default
  });
  var statusEl = document.createElement("p");
  statusEl.className = "error";
  statusEl.hidden = true;
  statusEl.dataset.adobeStatus = "true";
  root.appendChild(statusEl);
  function showStatus(message, isError = false) {
    if (!message) {
      statusEl.hidden = true;
      statusEl.textContent = "";
      return;
    }
    statusEl.hidden = false;
    statusEl.textContent = message;
    statusEl.style.color = isError ? "#b00020" : "#1a1a1a";
  }
  function withCandidates(role2) {
    return __spreadProps(__spreadValues({}, role2), {
      candidates: buildFontCandidates(role2.family, role2.style)
    });
  }
  function buildPayload(result, input) {
    return {
      canvasWidth: input.canvasWidth,
      canvasHeight: input.canvasHeight,
      result: {
        headline: withCandidates(result.headline),
        subheader: withCandidates(result.subheader),
        body: withCandidates(result.body)
      }
    };
  }
  async function ensureHostLoaded(cs) {
    const ping = await evalScriptSafe(cs, "scafoPing()");
    if (ping.ok && ping.result && ping.result !== "EvalScript_Err!" && !ping.result.includes("is undefined")) {
      return;
    }
    const extPath = toExtendScriptPath(cs.getSystemPath("extension"));
    const hostPath = `${extPath}/host/scafo-host.jsx`;
    const load = await evalScriptSafe(cs, `$.evalFile("${hostPath}")`);
    if (!load.ok) {
      throw load.error;
    }
    const again = await evalScriptSafe(cs, "scafoPing()");
    if (!again.ok || !again.result || again.result === "EvalScript_Err!" || again.result.includes("is undefined")) {
      throw new Error(
        "Could not load Scafo host scripts. Reload the panel (or restart the Adobe app)."
      );
    }
  }
  async function applyToDocument(cs, payload) {
    await ensureHostLoaded(cs);
    const arg = JSON.stringify(JSON.stringify(payload));
    const rawResult = await evalScriptSafe(cs, `scafoApplyHierarchy(${arg})`);
    if (!rawResult.ok) {
      return { ok: false, message: rawResult.error.message };
    }
    const raw = rawResult.result;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {
        ok: false,
        message: raw || "Empty response from Adobe host."
      };
    }
  }
  async function downloadRoleCard(result) {
    const width = 1e3;
    const height = 720;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx2 = canvas.getContext("2d");
    if (!ctx2) return;
    ctx2.fillStyle = "#f4f4f4";
    ctx2.fillRect(0, 0, width, height);
    ctx2.fillStyle = "#ffffff";
    ctx2.fillRect(40, 40, width - 80, height - 80);
    ctx2.fillStyle = "#000";
    ctx2.font = "700 40px Georgia, serif";
    ctx2.fillText("Scafo.", 72, 110);
    const lines = [
      { label: "Headline", role: result.headline, sample: "The quick hierarchy" },
      { label: "Sub-header", role: result.subheader, sample: "Paired for contrast" },
      {
        label: "Body",
        role: result.body,
        sample: "Body copy sample \u2014 readable measure from one main face."
      }
    ];
    let y = 180;
    for (const line of lines) {
      ctx2.fillStyle = "#666";
      ctx2.font = "12px system-ui, sans-serif";
      ctx2.fillText(
        `${line.label} \xB7 ${line.role.family} \xB7 ${line.role.size}px`,
        72,
        y
      );
      y += 28;
      ctx2.fillStyle = "#111";
      ctx2.font = `400 ${Math.min(line.role.size, 64)}px "${line.role.family}", Georgia, serif`;
      ctx2.fillText(line.sample, 72, y, width - 160);
      y += Math.min(line.role.size, 64) + 36;
    }
    const blob = await new Promise(
      (resolve) => canvas.toBlob((b) => resolve(b), "image/png")
    );
    if (!blob) return;
    const safe = result.headline.family.replace(/[^a-z0-9]+/gi, "-").toLowerCase();
    try {
      await savePng(blob, `scafo-${safe}-hierarchy.png`);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      warn("PNG save skipped", {
        message: err instanceof Error ? err.message : String(err)
      });
    }
  }
  async function boot() {
    var _a;
    const inCep = isCepEnvironment();
    let cs = null;
    if (inCep) {
      const bridge = await safeRun(async () => {
        const iface = createCSInterface();
        await ensureHostLoaded(iface);
        return iface;
      }, { source: "host", lastAction: "cep-boot" });
      if (bridge.ok) {
        cs = bridge.value;
        try {
          const envRaw = cs.getHostEnvironment();
          const env = JSON.parse(envRaw);
          showStatus(`Connected to ${(_a = env.appName) != null ? _a : "Adobe app"}.`, false);
          info("CEP host connected", { app: env.appName });
          setTimeout(() => showStatus(null), 2200);
        } catch (e) {
          showStatus(null);
        }
      } else {
        const msg = bridge.error instanceof Error ? bridge.error.message : "CEP host bridge unavailable.";
        showStatus(msg, true);
        reportError(bridge.error, { source: "host", lastAction: "cep-boot", fatal: false });
      }
    } else {
      showStatus(
        "Preview mode (not inside Adobe CEP). Analyse works; Apply needs Illustrator / Photoshop / InDesign.",
        false
      );
    }
    mountScafoUi(
      root,
      {
        async onScreenshot(result, input) {
          var _a2;
          showStatus(null);
          if (!cs) {
            await downloadRoleCard(result);
            showStatus(
              "PNG downloaded (panel preview). Load this extension in an Adobe app to apply text.",
              false
            );
            return;
          }
          const run = await safeRun(async () => {
            const payload = buildPayload(result, input);
            return applyToDocument(cs, payload);
          }, {
            source: "host",
            lastAction: "apply-hierarchy"
          });
          if (!run.ok) {
            const msg = run.error instanceof Error ? run.error.message : "Failed to apply hierarchy.";
            showStatus(msg, true);
            reportError(run.error, {
              source: "host",
              lastAction: "apply-hierarchy",
              fatal: false
            });
            return;
          }
          const hostResult = run.value;
          if (!hostResult.ok) {
            showStatus(hostResult.message, true);
            reportError(hostResult.message, {
              source: "host",
              lastAction: "apply-hierarchy",
              fatal: false
            });
            return;
          }
          const warnText = hostResult.warnings && hostResult.warnings.length ? ` ${hostResult.warnings.slice(0, 2).join(" \xB7 ")}` : "";
          showStatus(((_a2 = hostResult.message) != null ? _a2 : "Applied.") + warnText, false);
          info("Hierarchy applied", { host: hostResult.host });
          await safeRun(() => downloadRoleCard(result), {
            source: "export",
            lastAction: "png-card"
          });
        }
      },
      { host: "adobe", version: "0.1.0" }
    );
  }
  void boot();
})();
//# sourceMappingURL=panel.js.map
