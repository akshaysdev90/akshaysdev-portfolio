/* global app, $ */
/**
 * Scafo Adobe host bridge — loaded by CEP ScriptPath in Illustrator, Photoshop, InDesign.
 * ExtendScript (ES3). Entry points called from the panel via CSInterface.evalScript.
 */

#include "fonts.jsx"
#include "illustrator.jsx"
#include "photoshop.jsx"
#include "indesign.jsx"

function scafoDetectHost() {
  var name = scafoLower(app.name);
  if (name.indexOf("illustrator") >= 0) return "illustrator";
  if (name.indexOf("photoshop") >= 0) return "photoshop";
  if (name.indexOf("indesign") >= 0) return "indesign";
  return "adobe";
}

/**
 * @param {string} payloadJson stringified ApplyHierarchyPayload
 * @returns {string} JSON HostApplyResult
 */
function scafoApplyHierarchy(payloadJson) {
  try {
    var payload =
      typeof payloadJson === "string" ? scafoJsonParse(payloadJson) : payloadJson;
    if (!payload || !payload.result) {
      return scafoJsonStringify({
        ok: false,
        message: "Missing analyse result payload."
      });
    }

    var host = scafoDetectHost();
    var out;
    if (host === "illustrator") out = scafoApplyIllustrator(payload);
    else if (host === "photoshop") out = scafoApplyPhotoshop(payload);
    else if (host === "indesign") out = scafoApplyInDesign(payload);
    else {
      out = {
        ok: false,
        host: host,
        message: "Unsupported Adobe host: " + app.name
      };
    }
    return scafoJsonStringify(out);
  } catch (e) {
    return scafoJsonStringify({
      ok: false,
      host: scafoDetectHost(),
      message: String((e && e.message) || e)
    });
  }
}

/** Health check used by the panel on load. */
function scafoPing() {
  return scafoJsonStringify({
    ok: true,
    host: scafoDetectHost(),
    appName: String(app.name),
    appVersion: String(app.version)
  });
}
