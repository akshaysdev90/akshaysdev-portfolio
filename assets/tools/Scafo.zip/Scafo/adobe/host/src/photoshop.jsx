/* global app, UnitValue, LayerKind, Justification, TextType, Units, SolidColor */
/**
 * Apply Scafo hierarchy in Adobe Photoshop (ExtendScript / CEP).
 */

function scafoApplyPhotoshop(payload) {
  if (!app.documents.length) {
    return {
      ok: false,
      host: "photoshop",
      message: "Open a document in Photoshop before applying Scafo."
    };
  }

  var doc = app.activeDocument;
  var width = Math.max(1, Number(payload.canvasWidth) || 800);
  var height = Math.max(1, Number(payload.canvasHeight) || 600);
  var result = payload.result;
  var warnings = [];
  var prevUnits = app.preferences.rulerUnits;
  app.preferences.rulerUnits = Units.PIXELS;

  try {
    var pad = Math.max(24, Math.round(Math.min(width, height) * 0.08));
    var startX = pad;
    var cursorY = pad;
    var maxW = Math.max(8, width - pad * 2);

    var group = doc.layerSets.add();
    group.name = "Scafo Hierarchy";

    cursorY = scafoPsCreateText(
      group,
      result.headline,
      "Headline sample",
      startX,
      cursorY,
      maxW,
      warnings
    );
    cursorY += Math.max(12, result.subheader.size * 0.45);

    cursorY = scafoPsCreateText(
      group,
      result.subheader,
      "Sub-header sample",
      startX,
      cursorY,
      maxW,
      warnings
    );
    cursorY += Math.max(10, result.body.size * 0.55);

    scafoPsCreateText(
      group,
      result.body,
      "Body copy sample — Scafo builds a readable measure and contrast from one main face.",
      startX,
      cursorY,
      maxW,
      warnings
    );
  } finally {
    app.preferences.rulerUnits = prevUnits;
  }

  return {
    ok: true,
    host: "photoshop",
    warnings: warnings,
    message: warnings.length
      ? "Hierarchy created with font fallbacks."
      : "Hierarchy created in the active document."
  };
}

function scafoPsCreateText(group, role, characters, x, y, maxW, warnings) {
  var layer = group.artLayers.add();
  layer.kind = LayerKind.TEXT;
  layer.name = role.family + " " + role.size;

  var ti = layer.textItem;
  ti.kind = TextType.POINTTEXT;
  ti.contents = characters;
  ti.size = new UnitValue(role.size, "px");
  ti.color = scafoPsBlack();
  ti.justification = Justification.LEFT;
  ti.position = [x, y + role.size];

  var candidates = scafoPhotoshopFontCandidates(
    role.family,
    role.style,
    role.candidates || []
  );

  var applied = null;
  var i;
  for (i = 0; i < candidates.length; i++) {
    try {
      ti.font = candidates[i];
      applied = String(ti.font);
      break;
    } catch (eFont) {}
  }

  if (!applied) {
    throw new Error(
      'Could not apply a font for "' +
        role.family +
        '". Install the font or try a system face like Arial.'
    );
  }

  var famKey = scafoLower(role.family).replace(/\s+/g, "");
  if (scafoLower(applied).indexOf(famKey) < 0) {
    warnings.push('"' + role.family + '" → used PostScript font "' + applied + '"');
  }

  // maxW reserved for future paragraph text; PS point text is single-line by default
  if (maxW < 0) warnings.push("Invalid canvas width.");

  return y + role.size * 1.35;
}

function scafoPsBlack() {
  var c = new SolidColor();
  c.rgb.red = 0;
  c.rgb.green = 0;
  c.rgb.blue = 0;
  return c;
}
