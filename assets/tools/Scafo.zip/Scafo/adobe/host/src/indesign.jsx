/* global app, MeasurementUnits, FitOptions */
/**
 * Apply Scafo hierarchy in Adobe InDesign (ExtendScript / CEP).
 */

function scafoApplyInDesign(payload) {
  if (!app.documents.length) {
    return {
      ok: false,
      host: "indesign",
      message: "Open a document in InDesign before applying Scafo."
    };
  }

  var doc = app.activeDocument;
  var page = app.layoutWindows.length
    ? app.activeWindow.activePage
    : doc.pages[0];

  var width = Math.max(1, Number(payload.canvasWidth) || 800);
  var height = Math.max(1, Number(payload.canvasHeight) || 600);
  var result = payload.result;
  var warnings = [];

  var oldUnits = doc.viewPreferences.horizontalMeasurementUnits;
  doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.PIXELS;
  doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.PIXELS;

  try {
    var bounds = page.bounds; // [y1, x1, y2, x2]
    var pageW = bounds[3] - bounds[1];
    var pageH = bounds[2] - bounds[0];
    var originX = bounds[1] + Math.max(24, (pageW - width) / 2);
    var originY = bounds[0] + Math.max(24, (pageH - height) / 2);
    var pad = Math.max(24, Math.round(Math.min(width, height) * 0.08));
    var textW = width - pad * 2;
    var cursorY = originY + pad;

    var layer;
    try {
      layer = doc.layers.itemByName("Scafo Hierarchy");
      if (!layer.isValid) throw new Error("missing");
    } catch (eLayer) {
      layer = doc.layers.add({ name: "Scafo Hierarchy" });
    }
    layer.locked = false;

    cursorY = scafoIdCreateText(
      page,
      layer,
      result.headline,
      "Headline sample",
      originX + pad,
      cursorY,
      textW,
      warnings
    );
    cursorY += Math.max(12, result.subheader.size * 0.45);

    cursorY = scafoIdCreateText(
      page,
      layer,
      result.subheader,
      "Sub-header sample",
      originX + pad,
      cursorY,
      textW,
      warnings
    );
    cursorY += Math.max(10, result.body.size * 0.55);

    scafoIdCreateText(
      page,
      layer,
      result.body,
      "Body copy sample — Scafo builds a readable measure and contrast from one main face.",
      originX + pad,
      cursorY,
      textW,
      warnings
    );
  } finally {
    doc.viewPreferences.horizontalMeasurementUnits = oldUnits;
  }

  return {
    ok: true,
    host: "indesign",
    warnings: warnings,
    message: warnings.length
      ? "Hierarchy created with font fallbacks."
      : "Hierarchy created on the active page."
  };
}

function scafoIdCreateText(page, layer, role, characters, x, y, textW, warnings) {
  var frameH = Math.max(role.size * 2.2, 36);
  var tf = page.textFrames.add(layer, undefined, undefined, {
    geometricBounds: [y, x, y + frameH, x + textW],
    contents: characters
  });
  tf.name = role.family + " " + role.size;

  var font = scafoFindInDesignFont(role.family, role.style);
  if (!font) {
    throw new Error(
      'Could not load a font for "' +
        role.family +
        '". Install it or pick a face available in InDesign → Type → Font.'
    );
  }

  var text = tf.texts[0];
  text.appliedFont = font;
  try {
    if (role.style) text.fontStyle = role.style;
  } catch (eStyle) {
    try {
      text.fontStyle = "Regular";
    } catch (eReg) {}
  }
  text.pointSize = role.size;
  text.fillColor = scafoIdBlack();

  if (scafoLower(font.fontFamily) !== scafoLower(role.family)) {
    warnings.push(
      '"' + role.family + '" → used "' + font.fontFamily + '"'
    );
  }

  // Grow frame to fit
  try {
    tf.fit(FitOptions.FRAME_TO_CONTENT);
  } catch (eFit) {}

  var b = tf.geometricBounds;
  return b[2]; // bottom Y for next cursor
}

function scafoIdBlack() {
  try {
    return app.activeDocument.swatches.itemByName("Black");
  } catch (e) {
    return app.activeDocument.swatches[1];
  }
}
