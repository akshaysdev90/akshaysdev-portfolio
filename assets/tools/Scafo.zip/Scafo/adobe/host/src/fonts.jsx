/* global app */
/**
 * Shared Adobe ExtendScript font helpers (ES3-safe).
 * Loaded via #include from scafo-host.jsx.
 */

function scafoJsonParse(str) {
  if (typeof JSON !== "undefined" && JSON.parse) {
    return JSON.parse(str);
  }
  return eval("(" + str + ")");
}

function scafoJsonStringify(obj) {
  if (typeof JSON !== "undefined" && JSON.stringify) {
    return JSON.stringify(obj);
  }
  // Minimal fallback for simple result objects
  if (obj === null) return "null";
  if (typeof obj === "string") return '"' + obj.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
  if (typeof obj === "number" || typeof obj === "boolean") return String(obj);
  if (obj instanceof Array) {
    var parts = [];
    for (var i = 0; i < obj.length; i++) parts.push(scafoJsonStringify(obj[i]));
    return "[" + parts.join(",") + "]";
  }
  var keys = [];
  for (var k in obj) {
    if (obj.hasOwnProperty(k)) {
      keys.push(scafoJsonStringify(k) + ":" + scafoJsonStringify(obj[k]));
    }
  }
  return "{" + keys.join(",") + "}";
}

function scafoLower(s) {
  return String(s || "").toLowerCase();
}

function scafoAliasFamilies(family) {
  var key = scafoLower(family);
  var map = {
    helvetica: ["Helvetica Neue", "Arial", "Helvetica"],
    "helvetica neue": ["Helvetica", "Arial"],
    "times new roman": ["Times", "Times New Roman", "Georgia"],
    garamond: ["Adobe Garamond Pro", "Garamond", "EB Garamond"],
    "source sans 3": ["Source Sans Pro", "Source Sans 3"],
    "source serif 4": ["Source Serif Pro", "Source Serif 4"],
    "sf pro": ["SF Pro Text", "Helvetica Neue", "Arial"],
    inter: ["Inter", "Arial", "Helvetica"],
    roboto: ["Roboto", "Arial"],
    poppins: ["Poppins", "Arial"],
    seoulnamsan: ["Seoul Namsan", "Arial"]
  };
  return map[key] || [];
}

function scafoStylePrefs(preferred) {
  var p = preferred || "Regular";
  return [
    p,
    "Regular",
    "Roman",
    "Book",
    "Medium",
    "SemiBold",
    "Semi Bold",
    "Demibold",
    "Bold",
    "Light"
  ];
}

/**
 * Illustrator: returns TextFont or null.
 */
function scafoFindIllustratorFont(family, style) {
  var fonts = app.textFonts;
  var wanted = [family].concat(scafoAliasFamilies(family));
  var prefs = scafoStylePrefs(style);
  var i, j, k, f, fam, sty;

  for (i = 0; i < wanted.length; i++) {
    var targetFam = scafoLower(wanted[i]);
    var familyFonts = [];
    for (j = 0; j < fonts.length; j++) {
      f = fonts[j];
      fam = scafoLower(f.family);
      if (fam === targetFam || scafoLower(f.name) === targetFam) {
        familyFonts.push(f);
      }
    }
    if (!familyFonts.length) continue;

    for (k = 0; k < prefs.length; k++) {
      var pref = scafoLower(prefs[k]);
      for (j = 0; j < familyFonts.length; j++) {
        sty = scafoLower(familyFonts[j].style);
        if (sty === pref) return familyFonts[j];
      }
    }
    return familyFonts[0];
  }

  // Absolute fallbacks
  var fallbacks = ["Myriad Pro", "Arial", "Helvetica", "Minion Pro"];
  for (i = 0; i < fallbacks.length; i++) {
    for (j = 0; j < fonts.length; j++) {
      if (scafoLower(fonts[j].family) === scafoLower(fallbacks[i])) {
        return fonts[j];
      }
    }
  }
  return fonts.length ? fonts[0] : null;
}

/**
 * Photoshop: returns a PostScript font name string or null.
 * Photoshop DOM does not expose a reliable font enumerator in all versions,
 * so we try candidates; caller applies with try/catch.
 */
function scafoPhotoshopFontCandidates(family, style, extraCandidates) {
  var list = [];
  var push = function (v) {
    if (v && list.indexOf ? list.indexOf(v) < 0 : true) {
      // ES3 has no Array.indexOf in very old engines — linear check
      var exists = false;
      for (var i = 0; i < list.length; i++) {
        if (list[i] === v) {
          exists = true;
          break;
        }
      }
      if (!exists) list.push(v);
    }
  };

  if (extraCandidates && extraCandidates.length) {
    for (var c = 0; c < extraCandidates.length; c++) push(extraCandidates[c]);
  }

  var fam = family;
  var sty = style || "Regular";
  var noSpace = String(fam).replace(/\s+/g, "");
  var psStyle = String(sty).replace(/\s+/g, "");

  push(fam + "-" + psStyle);
  push(noSpace + "-" + psStyle);
  push(noSpace + psStyle);
  push(fam);
  push(noSpace);

  if (/regular|roman|book/i.test(sty)) {
    push(noSpace + "MT");
    push(fam + "MT");
    push(noSpace + "-Regular");
  }
  if (/bold/i.test(sty)) {
    push(noSpace + "-Bold");
    push(noSpace + "-BoldMT");
    push(fam + "-BoldMT");
  }

  var aliases = scafoAliasFamilies(fam);
  for (var a = 0; a < aliases.length; a++) {
    push(aliases[a]);
    push(String(aliases[a]).replace(/\s+/g, ""));
    push(String(aliases[a]).replace(/\s+/g, "") + "-" + psStyle);
  }

  push("ArialMT");
  push("Arial-BoldMT");
  push("Helvetica");
  push("MyriadPro-Regular");
  return list;
}

/**
 * InDesign: returns Font or null.
 */
function scafoFindInDesignFont(family, style) {
  var sty = style || "Regular";
  var wanted = [family].concat(scafoAliasFamilies(family));
  var prefs = scafoStylePrefs(sty);
  var i, j, font;

  for (i = 0; i < wanted.length; i++) {
    for (j = 0; j < prefs.length; j++) {
      try {
        font = app.fonts.itemByName(wanted[i] + "\t" + prefs[j]);
        if (font && font.isValid) return font;
      } catch (e1) {}
    }
    try {
      font = app.fonts.item(wanted[i]);
      if (font && font.isValid) return font;
    } catch (e2) {}
  }

  var fallbacks = ["Minion Pro", "Myriad Pro", "Arial", "Helvetica"];
  for (i = 0; i < fallbacks.length; i++) {
    try {
      font = app.fonts.item(fallbacks[i]);
      if (font && font.isValid) return font;
    } catch (e3) {}
  }
  return null;
}
