# Advanced install notes — Scafo v0.1.0

Most users should double-click **Install Scafo.command** (Mac) or **Install Scafo.bat** (Windows) in the package root.

## What install automates

| Step | Automatic? |
|------|------------|
| Strip macOS quarantine (when possible) | Yes |
| Adobe CEP `PlayerDebugMode` | Yes |
| Install CEP → Illustrator / Photoshop / InDesign | Yes |
| Copy Figma plugin to stable folder | Yes |
| Copy manifest path to clipboard | Yes |
| Open Finder/Explorer on `manifest.json` | Yes |
| Open helper HTML with next step | Yes |
| Import into Figma Desktop | **No** — one Import click |

## Uninstall

Run `advanced/uninstall.command` (Mac) or `advanced/uninstall.bat` (Windows).
