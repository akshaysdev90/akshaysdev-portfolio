/**
 * Remove Scafo host installs placed by the universal installer.
 */
import fs from "node:fs";
import path from "node:path";
import {
  cepTargetPath,
  figmaInstallRoot,
  rmrf,
  scafoSupportRoot,
} from "./lib/paths.mjs";

console.log("Scafo uninstall");
const adobe = cepTargetPath();
const figma = figmaInstallRoot();
const support = scafoSupportRoot();

console.log(
  `Adobe CEP:   ${rmrf(adobe) ? "removed" : "not found"}  (${adobe})`,
);
console.log(
  `Figma files: ${rmrf(figma) ? "removed" : "not found"}  (${figma})`,
);

const nextStep = path.join(support, "NEXT_STEP.html");
if (fs.existsSync(nextStep)) rmrf(nextStep);

if (fs.existsSync(support)) {
  const left = fs.readdirSync(support);
  if (left.length === 0) {
    fs.rmdirSync(support);
    console.log(`Cleaned: ${support}`);
  }
}

console.log("");
console.log(
  "Figma: remove the plugin under Plugins → Development if you imported it.",
);
console.log("Adobe PlayerDebugMode was left unchanged.");
