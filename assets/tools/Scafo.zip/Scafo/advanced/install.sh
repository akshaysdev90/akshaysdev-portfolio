#!/usr/bin/env bash
# Scafo install core (macOS / Linux) — v0.1.0
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION" 2>/dev/null || echo "0.1.0")"
EXTENSION_ID="com.scafo.adobe"

# Clear quarantine early
/usr/bin/xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true

if command -v node >/dev/null 2>&1 && [[ -f "$ROOT/advanced/install.mjs" ]]; then
  exec node "$ROOT/advanced/install.mjs" --root "$ROOT"
fi

echo "Installing Scafo v${VERSION}…"
echo ""

if [[ ! -f "$ROOT/adobe/CSXS/manifest.xml" || ! -f "$ROOT/figma/manifest.json" ]]; then
  echo "FAIL  Missing adobe/ or figma/ payloads"
  exit 1
fi

ok_adobe=0
ok_figma=0
upgraded=0

echo "• Adobe CEP debug mode"
if [[ "$(uname -s)" == "Darwin" ]]; then
  for v in 9 10 11 12; do
    defaults write "com.adobe.CSXS.${v}" PlayerDebugMode 1 2>/dev/null && echo "  OK  CSXS.${v}" || true
  done
else
  echo "  !!  Set PlayerDebugMode manually on this OS"
fi

echo "• Adobe (Illustrator / Photoshop / InDesign)"
if [[ "$(uname -s)" == "Darwin" ]]; then
  CEP_ROOT="${HOME}/Library/Application Support/Adobe/CEP/extensions"
else
  CEP_ROOT="${HOME}/.adobe/CEP/extensions"
fi
CEP_TARGET="${CEP_ROOT}/${EXTENSION_ID}"
mkdir -p "$CEP_ROOT"
if [[ -e "$CEP_TARGET" || -L "$CEP_TARGET" ]]; then upgraded=1; fi
rm -rf "$CEP_TARGET"
if cp -R "$ROOT/adobe" "$CEP_TARGET"; then
  [[ $upgraded -eq 1 ]] && echo "  OK  Updated → ${CEP_TARGET}" || echo "  OK  Installed → ${CEP_TARGET}"
  ok_adobe=1
else
  echo "  FAIL  Adobe CEP"
fi

echo "• Figma plugin files"
if [[ "$(uname -s)" == "Darwin" ]]; then
  FIGMA_TARGET="${HOME}/Library/Application Support/Scafo/figma"
  SUPPORT="${HOME}/Library/Application Support/Scafo"
else
  FIGMA_TARGET="${HOME}/.scafo/figma"
  SUPPORT="${HOME}/.scafo"
fi
MANIFEST="${FIGMA_TARGET}/manifest.json"
mkdir -p "$(dirname "$FIGMA_TARGET")"
fig_up=0
[[ -e "$FIGMA_TARGET" || -L "$FIGMA_TARGET" ]] && fig_up=1 && upgraded=1
rm -rf "$FIGMA_TARGET"
if cp -R "$ROOT/figma" "$FIGMA_TARGET"; then
  [[ $fig_up -eq 1 ]] && echo "  OK  Updated → ${FIGMA_TARGET}" || echo "  OK  Installed → ${FIGMA_TARGET}"
  ok_figma=1
else
  echo "  FAIL  Figma"
fi

echo ""
if [[ $upgraded -eq 1 ]]; then
  echo "╔══════════════════════════════════════════╗"
  echo "║         Scafo  ·  Updated                ║"
  echo "╚══════════════════════════════════════════╝"
else
  echo "╔══════════════════════════════════════════╗"
  echo "║         Scafo  ·  Installed              ║"
  echo "╚══════════════════════════════════════════╝"
fi
echo ""
echo "Ready now (after quit & relaunch Adobe apps):"
echo "  ✓  Illustrator   Window → Extensions → Scafo"
echo "  ✓  Photoshop     Window → Extensions (legacy) → Scafo"
echo "  ✓  InDesign      Window → Extensions → Scafo"
echo ""

if [[ $ok_figma -eq 1 ]]; then
  printf '%s' "$MANIFEST" | pbcopy 2>/dev/null || true
  if [[ "$(uname -s)" == "Darwin" ]]; then
    open -R "$MANIFEST" 2>/dev/null || true
  fi

  mkdir -p "$SUPPORT"
  NEXT="${SUPPORT}/NEXT_STEP.html"
  cat > "$NEXT" <<EOF
<!doctype html>
<html lang="en"><head><meta charset="utf-8" /><title>Scafo — one Figma step</title>
<style>
body{margin:0;font-family:"Avenir Next",sans-serif;background:linear-gradient(165deg,#f7f3ec,#e8dfd0);
color:#1c1916;min-height:100vh;display:grid;place-items:center;padding:32px}
main{width:min(560px,100%);background:#fffaf3;border:1px solid #d8cbb8;border-radius:18px;padding:28px}
h1{margin:0 0 8px;font-size:28px}.box{background:#1c1916;color:#f7f3ec;border-radius:12px;padding:16px;margin:16px 0}
code{display:block;margin:14px 0;padding:12px;background:#f3ebe0;border-radius:10px;word-break:break-all;font:13px ui-monospace,Menlo,monospace}
</style></head><body><main>
<h1>Scafo is almost ready</h1>
<p>Adobe apps are installed. One Figma click left.</p>
<div class="box">Figma → Plugins → Development → Import plugin from manifest… → paste/open this file</div>
<code>${MANIFEST}</code>
<p>Path is on your clipboard. Finder should be open on this file.</p>
<p>Then: Plugins → Development → <strong>Scafo</strong></p>
</main></body></html>
EOF
  open "$NEXT" 2>/dev/null || true

  if [[ -f "$ROOT/AFTER_INSTALL.html" ]]; then
    sed "s|__MANIFEST_PATH__|${MANIFEST}|g" "$ROOT/AFTER_INSTALL.html" > "$ROOT/AFTER_INSTALL.html.tmp" 2>/dev/null \
      && mv "$ROOT/AFTER_INSTALL.html.tmp" "$ROOT/AFTER_INSTALL.html" || true
  fi

  echo "One Figma step (cannot be automated):"
  echo "  Figma → Plugins → Development → Import plugin from manifest… → paste/open this file"
  echo "  ${MANIFEST}"
  echo "  (path copied to clipboard · helper page opened)"
  echo ""
fi

echo "Tip: re-run this installer anytime to update."
echo ""

[[ $ok_adobe -eq 1 && $ok_figma -eq 1 ]] && exit 0
exit 1
