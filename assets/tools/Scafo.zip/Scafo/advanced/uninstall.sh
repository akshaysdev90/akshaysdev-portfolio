#!/usr/bin/env bash
# Scafo uninstall — v0.1.0
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if command -v node >/dev/null 2>&1 && [[ -f "$ROOT/advanced/uninstall.mjs" ]]; then
  exec node "$ROOT/advanced/uninstall.mjs"
fi
EXTENSION_ID="com.scafo.adobe"
echo "Scafo uninstall"
if [[ "$(uname -s)" == "Darwin" ]]; then
  CEP_TARGET="${HOME}/Library/Application Support/Adobe/CEP/extensions/${EXTENSION_ID}"
  FIGMA_TARGET="${HOME}/Library/Application Support/Scafo/figma"
  SUPPORT="${HOME}/Library/Application Support/Scafo"
else
  CEP_TARGET="${HOME}/.adobe/CEP/extensions/${EXTENSION_ID}"
  FIGMA_TARGET="${HOME}/.scafo/figma"
  SUPPORT="${HOME}/.scafo"
fi
[[ -e "$CEP_TARGET" || -L "$CEP_TARGET" ]] && rm -rf "$CEP_TARGET" && echo "Adobe CEP: removed" || echo "Adobe CEP: not found"
[[ -e "$FIGMA_TARGET" || -L "$FIGMA_TARGET" ]] && rm -rf "$FIGMA_TARGET" && echo "Figma files: removed" || echo "Figma files: not found"
rm -f "${SUPPORT}/NEXT_STEP.html" 2>/dev/null || true
if [[ -d "$SUPPORT" ]] && [[ -z "$(ls -A "$SUPPORT" 2>/dev/null || true)" ]]; then rmdir "$SUPPORT" 2>/dev/null || true; fi
echo "Figma: remove under Plugins → Development if imported."
