/**
 * Universal Scafo installer (Node) — seamless UX for packed releases + monorepo.
 */
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  CSXS_VERSIONS,
  cepExtensionsRoot,
  cepTargetPath,
  EXTENSION_ID,
  figmaInstallRoot,
  pathExists,
  rmrf,
  scafoSupportRoot,
} from "./lib/paths.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function parseArgs(argv) {
  const opts = {
    packageRoot: null,
    forceCopy: true,
    skipDebug: false,
    skipOpen: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--root") opts.packageRoot = path.resolve(argv[++i] || "");
    else if (a.startsWith("--root="))
      opts.packageRoot = path.resolve(a.slice("--root=".length));
    else if (a === "--symlink") opts.forceCopy = false;
    else if (a === "--skip-debug") opts.skipDebug = true;
    else if (a === "--skip-open") opts.skipOpen = true;
  }
  return opts;
}

function resolvePackageRoot(explicit) {
  if (explicit) return explicit;
  // Packed: install.mjs in advanced/ next to ../figma ../adobe
  const packedFromAdvanced = path.resolve(__dirname, "..");
  if (
    fs.existsSync(path.join(packedFromAdvanced, "adobe/CSXS/manifest.xml")) &&
    fs.existsSync(path.join(packedFromAdvanced, "figma/manifest.json"))
  ) {
    return packedFromAdvanced;
  }
  // Packed: install.mjs at package root
  if (
    fs.existsSync(path.join(__dirname, "adobe/CSXS/manifest.xml")) &&
    fs.existsSync(path.join(__dirname, "figma/manifest.json"))
  ) {
    return __dirname;
  }
  // Monorepo: apps/universal/scripts
  return path.resolve(__dirname, "../../..");
}

function resolvePayloads(packageRoot) {
  const packedAdobe = path.join(packageRoot, "adobe");
  const packedFigma = path.join(packageRoot, "figma");
  if (
    fs.existsSync(path.join(packedAdobe, "CSXS/manifest.xml")) &&
    fs.existsSync(path.join(packedFigma, "manifest.json"))
  ) {
    return { adobe: packedAdobe, figma: packedFigma, mode: "packed" };
  }
  return {
    adobe: path.join(packageRoot, "apps/adobe/dist"),
    figma: path.join(packageRoot, "apps/figma/dist"),
    mode: "monorepo",
  };
}

function readVersion(packageRoot) {
  const fromPacked = path.join(packageRoot, "VERSION");
  if (fs.existsSync(fromPacked)) {
    return fs.readFileSync(fromPacked, "utf8").trim();
  }
  try {
    const pkg = JSON.parse(
      fs.readFileSync(path.join(packageRoot, "package.json"), "utf8"),
    );
    return pkg.version || "unknown";
  } catch {
    return "unknown";
  }
}

function stripQuarantine(dir) {
  if (process.platform !== "darwin") return;
  spawnSync("xattr", ["-dr", "com.apple.quarantine", dir], {
    encoding: "utf8",
  });
}

function enablePlayerDebugMode() {
  const results = [];
  if (process.platform === "darwin") {
    for (const v of CSXS_VERSIONS) {
      const domain = `com.adobe.CSXS.${v}`;
      const r = spawnSync(
        "defaults",
        ["write", domain, "PlayerDebugMode", "1"],
        { encoding: "utf8" },
      );
      results.push({ id: domain, ok: r.status === 0 });
    }
  } else if (process.platform === "win32") {
    for (const v of CSXS_VERSIONS) {
      const key = `HKCU\\Software\\Adobe\\CSXS.${v}`;
      const r = spawnSync(
        "reg",
        ["add", key, "/v", "PlayerDebugMode", "/t", "REG_SZ", "/d", "1", "/f"],
        { encoding: "utf8" },
      );
      results.push({ id: key, ok: r.status === 0 });
    }
  }
  return results;
}

function installAdobe(source, forceCopy) {
  if (!fs.existsSync(path.join(source, "CSXS/manifest.xml"))) {
    return {
      ok: false,
      target: cepTargetPath(),
      error: `Missing Adobe payload: ${source}`,
    };
  }
  const root = cepExtensionsRoot();
  const target = path.join(root, EXTENSION_ID);
  const upgrading = pathExists(target);
  fs.mkdirSync(root, { recursive: true });
  rmrf(target);

  if (!forceCopy) {
    try {
      fs.symlinkSync(
        source,
        target,
        process.platform === "win32" ? "junction" : "dir",
      );
      return { ok: true, target, mode: "symlink", upgrading };
    } catch (err) {
      console.warn("Symlink failed, copying instead:", err.message);
    }
  }
  try {
    fs.cpSync(source, target, { recursive: true });
    return { ok: true, target, mode: "copy", upgrading };
  } catch (err) {
    return {
      ok: false,
      target,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

function installFigma(source) {
  if (!fs.existsSync(path.join(source, "manifest.json"))) {
    return {
      ok: false,
      target: figmaInstallRoot(),
      error: `Missing Figma payload: ${source}`,
    };
  }
  const target = figmaInstallRoot();
  const upgrading = pathExists(target);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  rmrf(target);
  try {
    fs.cpSync(source, target, { recursive: true });
    return {
      ok: true,
      target,
      manifest: path.join(target, "manifest.json"),
      upgrading,
    };
  } catch (err) {
    return {
      ok: false,
      target,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

function copyToClipboard(text) {
  if (process.platform === "darwin") {
    const r = spawnSync("pbcopy", [], { input: text, encoding: "utf8" });
    return r.status === 0;
  }
  if (process.platform === "win32") {
    const r = spawnSync("powershell", [
      "-NoProfile",
      "-Command",
      "Set-Clipboard -Value $input",
    ], { input: text, encoding: "utf8" });
    return r.status === 0;
  }
  return false;
}

function revealInFileManager(filePath) {
  if (process.platform === "darwin") {
    spawnSync("open", ["-R", filePath], { encoding: "utf8" });
    return;
  }
  if (process.platform === "win32") {
    spawnSync("explorer.exe", [`/select,${filePath}`], { encoding: "utf8" });
  }
}

function writeNextStepHtml(manifestPath, version) {
  const support = scafoSupportRoot();
  fs.mkdirSync(support, { recursive: true });
  const htmlPath = path.join(support, "NEXT_STEP.html");
  const fileUrl = `file://${manifestPath.split(path.sep).map(encodeURIComponent).join("/")}`;
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Scafo — one Figma step</title>
  <style>
    :root { color-scheme: light; }
    body { margin: 0; font-family: "Avenir Next", "Segoe UI", sans-serif;
      background: linear-gradient(165deg, #f7f3ec 0%, #ebe4d8 45%, #e2d6c4 100%);
      color: #1c1916; min-height: 100vh; display: grid; place-items: center; padding: 32px; }
    main { width: min(560px, 100%); background: rgba(255,252,247,.92); border: 1px solid #d8cbb8;
      border-radius: 18px; padding: 28px 28px 24px; box-shadow: 0 18px 50px rgba(60,40,20,.08); }
    h1 { margin: 0 0 6px; font-size: 28px; letter-spacing: -.02em; }
    .tag { margin: 0 0 22px; color: #6b6258; font-size: 15px; }
    .step { background: #1c1916; color: #f7f3ec; border-radius: 12px; padding: 16px 18px; margin: 0 0 18px; }
    .step strong { display: block; font-size: 13px; letter-spacing: .04em; text-transform: uppercase; opacity: .7; margin-bottom: 8px; }
    .step p { margin: 0; font-size: 17px; line-height: 1.45; }
    code { display: block; margin-top: 14px; padding: 12px 14px; border-radius: 10px;
      background: #f3ebe0; color: #2a241e; font: 13px/1.4 ui-monospace, Menlo, Consolas, monospace;
      word-break: break-all; }
    ul { margin: 0; padding-left: 18px; color: #3d352c; }
    li { margin: 8px 0; }
    .ok { margin-top: 20px; font-size: 14px; color: #2f6b3a; }
  </style>
</head>
<body>
  <main>
    <h1>Scafo is almost ready</h1>
    <p class="tag">v${version} · Adobe apps are installed. One Figma click left.</p>
    <div class="step">
      <strong>Do this in Figma Desktop</strong>
      <p>Plugins → Development → Import plugin from manifest… → choose the file below (path is already on your clipboard).</p>
    </div>
    <code id="path">${manifestPath.replace(/</g, "&lt;")}</code>
    <ul>
      <li>Finder / Explorer should already be open on this file</li>
      <li>After import: Plugins → Development → <strong>Scafo</strong></li>
      <li>Quit &amp; relaunch Illustrator / Photoshop / InDesign, then Window → Extensions → Scafo</li>
    </ul>
    <p class="ok">Illustrator · Photoshop · InDesign · Figma (after import)</p>
  </main>
  <script>
    // Keep path easy to select; file URL for power users
    console.log(${JSON.stringify(fileUrl)});
  </script>
</body>
</html>`;
  fs.writeFileSync(htmlPath, html);
  return htmlPath;
}

function openPath(p) {
  if (process.platform === "darwin") spawnSync("open", [p]);
  else if (process.platform === "win32") spawnSync("cmd", ["/c", "start", "", p], {
    shell: true,
  });
}

function printBanner(version, upgradingAny) {
  console.log("");
  console.log("╔══════════════════════════════════════════╗");
  console.log(
    upgradingAny
      ? "║         Scafo  ·  Updated                ║"
      : "║         Scafo  ·  Installed              ║",
  );
  console.log(`║         v${String(version).padEnd(33)}║`);
  console.log("╚══════════════════════════════════════════╝");
  console.log("");
}

const opts = parseArgs(process.argv.slice(2));
const packageRoot = resolvePackageRoot(opts.packageRoot);
const payloads = resolvePayloads(packageRoot);
const version = readVersion(packageRoot);

stripQuarantine(packageRoot);

console.log(`Installing Scafo v${version}…`);
console.log("");

const report = { adobeDebug: null, adobe: null, figma: null };

if (!opts.skipDebug) {
  console.log("• Adobe CEP debug mode");
  report.adobeDebug = enablePlayerDebugMode();
  const ok = (report.adobeDebug || []).filter((r) => r.ok).length;
  console.log(`  ${ok > 0 ? "OK" : "skipped"}  PlayerDebugMode (unsigned local panels)`);
}

console.log("• Adobe (Illustrator / Photoshop / InDesign)");
report.adobe = installAdobe(payloads.adobe, opts.forceCopy);
if (report.adobe.ok) {
  const verb = report.adobe.upgrading ? "Updated" : "Installed";
  console.log(`  OK  ${verb} → ${report.adobe.target}`);
} else {
  console.log(`  FAIL  ${report.adobe.error}`);
}

console.log("• Figma plugin files");
report.figma = installFigma(payloads.figma);
if (report.figma.ok) {
  const verb = report.figma.upgrading ? "Updated" : "Installed";
  console.log(`  OK  ${verb} → ${report.figma.target}`);
} else {
  console.log(`  FAIL  ${report.figma.error}`);
}

const upgradingAny = !!(report.adobe?.upgrading || report.figma?.upgrading);
printBanner(version, upgradingAny);

console.log("Ready now (after quit & relaunch Adobe apps):");
console.log("  ✓  Illustrator   Window → Extensions → Scafo");
console.log("  ✓  Photoshop     Window → Extensions (legacy) → Scafo");
console.log("  ✓  InDesign      Window → Extensions → Scafo");
console.log("");

if (report.figma.ok) {
  const manifest = report.figma.manifest;
  const clipped = copyToClipboard(manifest);
  if (!opts.skipOpen) {
    revealInFileManager(manifest);
    const nextHtml = writeNextStepHtml(manifest, version);
    openPath(nextHtml);
    const packageGuide = path.join(packageRoot, "AFTER_INSTALL.html");
    if (fs.existsSync(packageGuide)) {
      // Refresh package guide with concrete path for offline reading
      try {
        let guide = fs.readFileSync(packageGuide, "utf8");
        guide = guide.replace(/__MANIFEST_PATH__/g, manifest);
        fs.writeFileSync(packageGuide, guide);
      } catch {
        /* ignore */
      }
    }
  }

  console.log("One Figma step (cannot be automated):");
  console.log(
    "  Figma → Plugins → Development → Import plugin from manifest… → paste/open this file",
  );
  console.log(`  ${manifest}`);
  if (clipped) console.log("  (path copied to clipboard)");
  console.log("");
}

if (!report.adobe.ok || !report.figma.ok) {
  console.log("Something failed — see messages above.");
  process.exit(1);
}

console.log("Tip: re-run this installer anytime to update.");
console.log("");
process.exit(0);
