@echo off
REM Scafo — primary Windows installer — v0.1.0
REM Double-click this file. No PowerShell policy change required.
setlocal
cd /d "%~dp0"
echo.
echo   Installing Scafo...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0advanced\install.ps1" -PackageRoot "%~dp0"
set ERR=%ERRORLEVEL%
echo.
if %ERR% EQU 0 (
  echo   Done. You can close this window.
) else (
  echo   Install reported a problem ^(exit %ERR%^).
)
echo.
pause
exit /b %ERR%
