/* global app, RGBColor, Justification */
/**
 * Apply Scafo hierarchy in Adobe Illustrator (ExtendScript).
 */

function scafoApplyIllustrator(payload) {
  if (!app.documents.length) {
    return {
      ok: false,
      host: "illustrator",
      message: "Open a document in Illustrator before applying Scafo."
    };
  }

  var doc = app.activeDocument;
  var width = Math.max(1, Number(payload.canvasWidth) || 800);
  var height = Math.max(1, Number(payload.canvasHeight) || 600);
  var result = payload.result;
  var warnings = [];

  var abIndex = doc.artboards.getActiveArtboardIndex();
  var ab = doc.artboards[abIndex].artboardRect; // [left, top, right, bottom]
  var abLeft = ab[0];
  var abTop = ab[1];
  var abRight = ab[2];
  var abBottom = ab[3];
  var abW = abRight - abLeft;
  var abH = abTop - abBottom;
  var originX = abLeft + Math.max(24, (abW - width) / 2);
  var originY = abTop - Math.max(24, (abH - height) / 2);

  var pad = Math.max(24, Math.round(Math.min(width, height) * 0.08));
  var cursorY = originY - pad;
  var textWidth = Math.max(8, width - pad * 2);

  var group = doc.groupItems.add();
  group.name = "Scafo Hierarchy";

  var headline = scafoAiCreateText(
    group,
    result.headline,
    "Headline sample",
    originX + pad,
    cursorY,
    textWidth,
    warnings
  );
  cursorY = headline.top - headline.height - Math.max(12, result.subheader.size * 0.45);

  var sub = scafoAiCreateText(
    group,
    result.subheader,
    "Sub-header sample",
    originX + pad,
    cursorY,
    textWidth,
    warnings
  );
  cursorY = sub.top - sub.height - Math.max(10, result.body.size * 0.55);

  scafoAiCreateText(
    group,
    result.body,
    "Body copy sample — Scafo builds a readable measure and contrast from one main face.",
    originX + pad,
    cursorY,
    textWidth,
    warnings
  );

  return {
    ok: true,
    host: "illustrator",
    warnings: warnings,
    message: warnings.length
      ? "Hierarchy created with font fallbacks."
      : "Hierarchy created on the active artboard."
  };
}

function scafoAiCreateText(group, role, characters, x, y, maxWidth, warnings) {
  var tf = group.textFrames.add();
  tf.contents = characters;
  tf.name = role.family + " " + role.size;

  var font = scafoFindIllustratorFont(role.family, role.style);
  if (!font) {
    throw new Error('Could not load a font for "' + role.family + '".');
  }
  if (scafoLower(font.family) !== scafoLower(role.family)) {
    warnings.push(
      '"' + role.family + '" (' + role.style + ') → used "' + font.family + '" / ' + font.style
    );
  }

  var attr = tf.textRange.characterAttributes;
  attr.size = role.size;
  attr.textFont = font;
  attr.fillColor = scafoAiBlack();

  try {
    tf.textRange.paragraphAttributes.justification = Justification.LEFT;
  } catch (eJust) {}

  tf.left = x;
  tf.top = y;

  // Soft wrap wide lines into an area text frame
  try {
    if (tf.width > maxWidth && maxWidth > 8) {
      var rectH = Math.max(role.size * 3.2, 48);
      var rect = group.pathItems.rectangle(y, x, maxWidth, rectH);
      var area = group.textFrames.areaText(rect);
      area.contents = characters;
      area.textRange.characterAttributes.size = role.size;
      area.textRange.characterAttributes.textFont = font;
      area.textRange.characterAttributes.fillColor = scafoAiBlack();
      area.name = tf.name;
      tf.remove();
      return area;
    }
  } catch (eArea) {}

  return tf;
}

function scafoAiBlack() {
  var c = new RGBColor();
  c.red = 0;
  c.green = 0;
  c.blue = 0;
  return c;
}
