# Scafo install core (Windows) — v0.1.0
# Called by Install Scafo.bat with -ExecutionPolicy Bypass (no user policy change).
param(
  [string]$PackageRoot = ""
)

$ErrorActionPreference = "Stop"

if (-not $PackageRoot) {
  $PackageRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
}
$PackageRoot = $PackageRoot.TrimEnd('\', '/')
$Advanced = Join-Path $PackageRoot "advanced"
$InstallMjs = Join-Path $Advanced "install.mjs"

$VersionFile = Join-Path $PackageRoot "VERSION"
$Version = if (Test-Path $VersionFile) { (Get-Content $VersionFile -Raw).Trim() } else { "0.1.0" }

$Node = Get-Command node -ErrorAction SilentlyContinue
if ($Node -and (Test-Path $InstallMjs)) {
  & node $InstallMjs --root $PackageRoot
  exit $LASTEXITCODE
}

Write-Host "Installing Scafo v$Version…"
Write-Host ""

$AdobeManifest = Join-Path $PackageRoot "adobe\CSXS\manifest.xml"
$FigmaSrc = Join-Path $PackageRoot "figma"
if (-not (Test-Path $AdobeManifest)) { throw "Missing adobe\CSXS\manifest.xml" }
if (-not (Test-Path (Join-Path $FigmaSrc "manifest.json"))) { throw "Missing figma\manifest.json" }

function Remove-PathForce([string]$Path) {
  if (Test-Path $Path) { Remove-Item -LiteralPath $Path -Recurse -Force }
}

Write-Host "• Adobe CEP debug mode"
foreach ($v in 9, 10, 11, 12) {
  $key = "HKCU:\Software\Adobe\CSXS.$v"
  try {
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    New-ItemProperty -Path $key -Name "PlayerDebugMode" -Value "1" -PropertyType String -Force | Out-Null
    Write-Host "  OK  CSXS.$v"
  } catch {
    Write-Host "  !!  CSXS.$v"
  }
}

$AppData = $env:APPDATA
if (-not $AppData) { $AppData = Join-Path $env:USERPROFILE "AppData\Roaming" }

Write-Host "• Adobe (Illustrator / Photoshop / InDesign)"
$CepRoot = Join-Path $AppData "Adobe\CEP\extensions"
$CepTarget = Join-Path $CepRoot "com.scafo.adobe"
$upgraded = $false
New-Item -ItemType Directory -Force -Path $CepRoot | Out-Null
if (Test-Path $CepTarget) { $upgraded = $true }
Remove-PathForce $CepTarget
Copy-Item -Path (Join-Path $PackageRoot "adobe") -Destination $CepTarget -Recurse -Force
if ($upgraded) { Write-Host "  OK  Updated → $CepTarget" } else { Write-Host "  OK  Installed → $CepTarget" }

Write-Host "• Figma plugin files"
$FigmaTarget = Join-Path $AppData "Scafo\figma"
$Support = Join-Path $AppData "Scafo"
$Manifest = Join-Path $FigmaTarget "manifest.json"
New-Item -ItemType Directory -Force -Path (Split-Path $FigmaTarget -Parent) | Out-Null
if (Test-Path $FigmaTarget) { $upgraded = $true }
Remove-PathForce $FigmaTarget
Copy-Item -Path $FigmaSrc -Destination $FigmaTarget -Recurse -Force
Write-Host "  OK  $(if (Test-Path $Manifest) { if ($upgraded) { 'Updated' } else { 'Installed' } } else { 'Installed' }) → $FigmaTarget"

Write-Host ""
if ($upgraded) {
  Write-Host "========  Scafo  ·  Updated  ========"
} else {
  Write-Host "========  Scafo  ·  Installed  ======"
}
Write-Host ""
Write-Host "Ready now (after quit & relaunch Adobe apps):"
Write-Host "  ✓  Illustrator   Window → Extensions → Scafo"
Write-Host "  ✓  Photoshop     Window → Extensions (legacy) → Scafo"
Write-Host "  ✓  InDesign      Window → Extensions → Scafo"
Write-Host ""

try { Set-Clipboard -Value $Manifest } catch { }
try { explorer.exe "/select,$Manifest" } catch { }

New-Item -ItemType Directory -Force -Path $Support | Out-Null
$Next = Join-Path $Support "NEXT_STEP.html"
@"
<!doctype html>
<html lang="en"><head><meta charset="utf-8" /><title>Scafo — one Figma step</title>
<style>
body{margin:0;font-family:Segoe UI,sans-serif;background:linear-gradient(165deg,#f7f3ec,#e8dfd0);
color:#1c1916;min-height:100vh;display:grid;place-items:center;padding:32px}
main{width:min(560px,100%);background:#fffaf3;border:1px solid #d8cbb8;border-radius:18px;padding:28px}
h1{margin:0 0 8px;font-size:28px}.box{background:#1c1916;color:#f7f3ec;border-radius:12px;padding:16px;margin:16px 0}
code{display:block;margin:14px 0;padding:12px;background:#f3ebe0;border-radius:10px;word-break:break-all;font:13px Consolas,monospace}
</style></head><body><main>
<h1>Scafo is almost ready</h1>
<p>Adobe apps are installed. One Figma click left.</p>
<div class="box">Figma → Plugins → Development → Import plugin from manifest… → paste/open this file</div>
<code>$Manifest</code>
<p>Path is on your clipboard. Explorer should be open on this file.</p>
<p>Then: Plugins → Development → <strong>Scafo</strong></p>
</main></body></html>
"@ | Set-Content -Path $Next -Encoding UTF8
try { Start-Process $Next } catch { }

$Guide = Join-Path $PackageRoot "AFTER_INSTALL.html"
if (Test-Path $Guide) {
  try {
    $text = (Get-Content $Guide -Raw).Replace("__MANIFEST_PATH__", $Manifest)
    Set-Content -Path $Guide -Value $text -Encoding UTF8
  } catch { }
}

Write-Host "One Figma step (cannot be automated):"
Write-Host "  Figma → Plugins → Development → Import plugin from manifest… → paste/open this file"
Write-Host "  $Manifest"
Write-Host "  (path copied to clipboard · helper page opened)"
Write-Host ""
Write-Host "Tip: re-run this installer anytime to update."
Write-Host ""
exit 0
