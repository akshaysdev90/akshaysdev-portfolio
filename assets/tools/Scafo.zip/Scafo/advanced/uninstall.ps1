# Scafo uninstall (Windows) — v0.1.0
$ErrorActionPreference = "Continue"
$PackageRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$UninstallMjs = Join-Path $PackageRoot "advanced\uninstall.mjs"
$Node = Get-Command node -ErrorAction SilentlyContinue
if ($Node -and (Test-Path $UninstallMjs)) {
  & node $UninstallMjs
  exit $LASTEXITCODE
}
Write-Host "Scafo uninstall"
$AppData = $env:APPDATA
if (-not $AppData) { $AppData = Join-Path $env:USERPROFILE "AppData\Roaming" }
$CepTarget = Join-Path $AppData "Adobe\CEP\extensions\com.scafo.adobe"
$FigmaTarget = Join-Path $AppData "Scafo\figma"
$Support = Join-Path $AppData "Scafo"
if (Test-Path $CepTarget) { Remove-Item -LiteralPath $CepTarget -Recurse -Force; Write-Host "Adobe CEP: removed" } else { Write-Host "Adobe CEP: not found" }
if (Test-Path $FigmaTarget) { Remove-Item -LiteralPath $FigmaTarget -Recurse -Force; Write-Host "Figma files: removed" } else { Write-Host "Figma files: not found" }
$Next = Join-Path $Support "NEXT_STEP.html"
if (Test-Path $Next) { Remove-Item -LiteralPath $Next -Force }
if ((Test-Path $Support) -and -not (Get-ChildItem -Force $Support | Select-Object -First 1)) {
  Remove-Item -LiteralPath $Support -Force
}
Write-Host "Figma: remove under Plugins → Development if imported."
